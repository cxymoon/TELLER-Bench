import os
import yaml
from transformers import AutoTokenizer
from openai import OpenAI
def load_yaml_prompt(file_path, sop_title, additional_context):
    """读取YAML并替换占位符"""
    with open(file_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    text = data["prompts"]["text"]
    text = text.replace("{{sop_title}}", sop_title)
    text = text.replace("{{additional_context}}", additional_context)
    return text


def main():
    # === 输入参数 ===
    sop_title = "Banking Deposit Business Handling Process"
    additional_context = '''
    ### 1. Business Overview
    *   **Scenario Name:** Banking Deposit Services Management
    *   **Industry:** Financial Services / Retail Banking
    *   **Primary Purpose / Value:** To provide secure, compliant, and efficient channels for customers to store funds, earning interest while ensuring the bank has the necessary liquidity to lend and invest. This scenario facilitates the primary inflow of capital for a bank's balance sheet.

    ### 2. Business Types
    *   **Retail Demand Deposit (Savings/Checking):** Processing day-to-day transaction account openings where funds are easily accessible.
    *   **Term Deposit (Certificate of Deposit - CD):** Handling fixed-term investments where customers lock in funds for a specific period at a higher interest rate.
    *   **Corporate/Business Deposit:** Managing high-volume deposit accounts for business entities, often requiring complex documentation and authorization structures.
    *   **Cash Deposit Operations:** The physical act of depositing cash via branch tellers or ATMs.

    ### 3. Process Description

    *   **Retail Demand Deposit Process:**
        1)  **Customer Verification (KYC):** The bank officer collects the customer's ID (passport, driver's license), proof of address, and tax identification number. The system performs automatic sanction screening and identity verification.
        2)  **Product Selection & Terms Agreement:** The customer selects a specific account type (e.g., Student Checking, High-Yield Savings). The officer explains fees, minimum balance requirements, and interest rates. The customer signs the digital or physical deposit agreement.
        3)  **Account Creation:** The officer inputs customer data into the Core Banking System (CBS), which generates a unique account number and links it to the customer's unique Customer Information File (CIF).
        4)  **Initial Funding:** The customer provides the opening balance via cash, check, or internal transfer. The system validates the funding source.
        5)  **Access Setup:** Issuance of debit card, checkbook ordering, and setup of online banking credentials.
        6)  **Output Generation:** The system outputs the new Account Number, Initial Balance Value, and Account Status (Active).

    *   **Term Deposit (CD) Process:**
        1)  **Needs Analysis & Rate Locking:** The customer inquires about current rates for different terms (e.g., 6 months, 1 year, 5 years). The system displays the current treasury-approved rates.
        2)  **Fund Allocation:** The customer specifies the principal amount to be invested. The system checks the source account for sufficient funds to cover the principal.
        3)  **Contract Generation:** The system generates a Term Deposit contract specifying the Principal Amount, Maturity Date, Interest Rate (APY), and Early Withdrawal Penalties.
        4)  **Execution & Debiting:** Upon customer approval, the system debits the source account and credits the new Term Deposit GL account.
        5)  **Output Generation:** The system outputs the CD Certificate Number, Maturity Date, Principal Amount, and Calculated Interest at Maturity.

    *   **Cash Deposit Operations (Counter) Process:**
        1)  **Transaction Initiation:** The customer presents a deposit slip (or swipes a debit card) and hands over physical cash to the teller.
        2)  **Cash Validation & Counting:** The teller runs the bills through a currency counter/discriminator to verify authenticity and total count.
        3)  **System Entry:** The teller inputs the account number and the total cash amount into the teller system.
        4)  **Double-Entry Confirmation:** The system validates the account status. The teller confirms the amount matches the machine count.
        5)  **Receipt Generation:** The system processes the credit to the customer's ledger balance. A receipt is printed.
        6)  **Output Generation:** The system outputs the Transaction Reference ID, Updated Account Balance, and Cash Drawer Total.

    ### 4. Key Roles and Responsibilities
    *   **Bank Teller / CSR (Customer Service Representative):** Responsible for face-to-face interaction, physical cash handling, basic identity verification, and data entry for deposits.
    *   **Personal Banker / Relationship Manager:** Handles complex account openings (Term Deposits, Business Accounts), advisory services, and relationship deepening.
    *   **Branch Manager:** Approves large cash transactions, overrides system blocks (within authority limits), and ensures audit compliance.
    *   **Compliance Officer / KYC Analyst:** Reviews flagged applications for potential money laundering (AML) risks or incomplete documentation.
    *   **System Administrator:** Ensures the Core Banking System and peripheral devices (cash counters, card readers) are operational and secure.

    ### 5. System and Tool Support
    *   **Core Banking System (CBS):** The central ledger (e.g., Oracle Flexcube, Temenos, Fiserv) that maintains account balances, customer master data, and processes transactions in real-time.
    *   **Teller Capture System:** The front-end interface used by tellers to input cash and check transactions.
    *   **CRM (Customer Relationship Management):** Stores interaction history and prompts bankers with cross-selling opportunities during the deposit process.
    *   **AML / Sanctions Screening Tool:** Automatically checks customer names against government watchlists (OFAC, Interpol) during onboarding.
    *   **Currency Discriminator / Counter:** Hardware used to count large volumes of cash and detect counterfeit bills.

    ### 6. Risks and Control Points
    *   **Risk Point 1: Money Laundering / Terrorist Financing:** Bad actors using deposits to legitimize illicit funds.
        *   *Control Measure:* Mandatory KYC/CIP (Customer Identification Program) checks; Automatic CTR (Currency Transaction Report) filing for cash deposits over a specific threshold (e.g., $10,000).
    *   **Risk Point 2: Counterfeit Currency:** Acceptance of fake bills resulting in financial loss.
        *   *Control Measure:* Use of certified currency detection machines; manual UV light checks for older bills; teller training on security features.
    *   **Risk Point 3: Data Entry Error:** Depositing funds into the wrong account due to a typo.
        *   *Control Measure:* Name-to-account matching verification (system displays account holder name for confirmation before posting); Dual control/supervisor approval for amounts over a certain limit.
    *   **Risk Point 4: Fraudulent Account Opening:** Identity theft used to open accounts for check fraud.
        *   *Control Measure:* Multi-factor authentication of ID documents (scanning barcodes on IDs); Third-party database verification (e.g., ChexSystems) to check banking history.

    ### 7. Typical Metrics and Measurement Methods
    *   **Average Account Opening Time (Turnaround Time):** Measured by the timestamps between the start of the application in the system and the generation of the account number.
    *   **Net New Money (NNM):** The numerical value of new funds brought into the bank minus funds withdrawn, measured daily or monthly.
    *   **Deposit Mix:** The ratio of low-cost deposits (checking/savings) to high-cost deposits (CDs) measured by aggregating total balances by product code.
    *   **Teller Transaction Accuracy:** The percentage of transactions processed without error corrections or balancing discrepancies at the end of the day.

    ### 8. Best Practices or Improvement Suggestions
    *   **Digital Onboarding Implementation:** Minimize in-branch processing by allowing customers to scan IDs and take selfies via mobile app for OCR data extraction, reducing manual entry errors and processing time.
    *   **Paperless Workflows:** Utilize e-signature pads and email delivery for receipts and contracts to reduce paper costs and storage risks.
    *   **Real-time Fraud Scoring:** Integrate AI-driven fraud detection that scores the risk of a deposit transaction in real-time based on location, device ID, and historical behavior.
    *   **Unified Banker Model:** Train staff to handle both teller duties (transactions) and platform duties (account opening) to optimize workforce utilization during peak and off-peak hours.

    '''
    yaml_file = "/Deposit/Deepseek-V3.2/graph_and_random_and_expand_affairs/prompts/Schema_Generation.yaml"
    system_prompt = "You are an SOP dataset schema generator. Note that <Field_to_be_obtained></Field_to_be_obtained> should include several final output fields from the SOP, preferably numerical values, that can be used to determine if the process is correct."
    # 初始化客户端
    client = OpenAI(
        api_key="",  # 替换为你的API Key
        base_url="https://"  # API中转地址
    )
    # === 读取YAML并填充 ===
    user_prompt = load_yaml_prompt(yaml_file, sop_title, additional_context)

    # 创建对话
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            }
        ],
        model="claude-sonnet-4-5-20250929",  # 指定模型
    )

    print(chat_completion.choices[0].message.content)

if __name__ == "__main__":
    main()

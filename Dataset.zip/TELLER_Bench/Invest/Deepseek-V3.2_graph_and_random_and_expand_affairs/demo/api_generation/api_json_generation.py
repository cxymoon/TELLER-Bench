import os
import yaml
from transformers import AutoTokenizer
from openai import OpenAI
def load_yaml_prompt(file_path, sop_file_contents, additional_context, each_api_metadata, sample_data):
    """读取YAML并替换占位符"""
    with open(file_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    text = data["prompts"]["text_2"]
    text = text.replace("{{sop_file_contents}}", sop_file_contents)
    text = text.replace("{{additional_context}}", additional_context)
    text = text.replace("{{each_api_metadata}}", each_api_metadata)
    text = text.replace("{{sample_data}}", sample_data)
    return text

def main():
    # === 输入参数 ===
    sop_file_contents = '''
        <SOP>

        1. Purpose

        The purpose of this Standard Operating Procedure is to establish a comprehensive, multi-layered framework for the execution of retail wealth management investment transactions within a banking and financial services environment, encompassing the full lifecycle from initial client risk profiling and investor suitability assessment through to the final execution and settlement of investment product subscriptions, including but not limited to open-ended mutual fund units and complex structured financial instruments such as Dual Currency Investments and Principal Protected Notes. This SOP ensures strict adherence to all applicable regulatory mandates governing investor protection, Know Your Customer (KYC) requirements, Anti-Money Laundering (AML) screening protocols, suitability and appropriateness assessments as prescribed under MiFID II equivalents and local banking supervisory frameworks, while simultaneously optimizing Assets Under Management (AUM) growth and fee-based revenue generation through systematic, auditable, and compliant sales processes. The procedure integrates automated risk-based decisioning engines, real-time compliance validation checkpoints, and multi-system orchestration across Wealth Management Systems (WMS), Customer Relationship Management (CRM) platforms, Sales Compliance Recording Systems (SCRS), and Risk Engines to achieve Straight-Through Processing (STP) rates exceeding industry benchmarks while maintaining zero-tolerance policies for miss-selling incidents and regulatory breaches.

        2. Scope

        This Standard Operating Procedure applies comprehensively to all Relationship Managers (RMs), Investment Product Specialists (IPSs), Compliance Officers, and Back Office Operations personnel who are directly or indirectly involved in the origination, processing, validation, execution, and post-trade settlement of investment product transactions across all channels including Branch, Phone Banking, Mobile Application, and Online Banking platforms within the organization's retail wealth management business unit. The scope explicitly encompasses three distinct but interconnected sub-business processes: (A) Risk Profiling and Investor Suitability Assessment, which establishes the foundational eligibility and investment parameters for each client; (B) Mutual Fund Subscription (Lump Sum), covering the direct purchase of open-ended mutual fund units through immediate debit from client settlement accounts; and (C) Structured Product Enrollment, addressing the sales, disclosure, and booking procedures for complex financial instruments requiring enhanced due diligence, mandatory audio-video recording, and regulatory cooling-off periods. The SOP governs all transactions originating from clients identified by unique client_id values within the system, processed by authorized relationship_manager_id personnel, and recorded with distinct transaction_id identifiers for complete audit trail purposes. Geographically, this procedure applies across all regions and branch_code locations where the organization maintains retail wealth management operations, with specific regional regulatory adaptations documented in supplementary annexes where local supervisory requirements impose additional or variant obligations beyond the baseline standards articulated herein.

        3. Definitions

        **Risk Tolerance Questionnaire** refers to the regulatory-mandated, multi-dimensional assessment instrument administered to each client to systematically capture quantitative and qualitative data pertaining to the client's age bracket, income stability characteristics, declared annual income (client_annual_income), total net worth (client_net_worth), investment experience measured in years (client_investment_experience_years), liquidity requirements categorized as Low, Medium, or High (client_liquidity_needs), investment time horizon preferences, psychological loss tolerance thresholds, and prior exposure to various asset classes, with all responses recorded in structured JSON format within the risk_questionnaire_responses field and subsequently processed through a proprietary weighted scoring algorithm to generate a risk_questionnaire_total_score ranging from zero to one hundred points.

        **Calculated Risk Profile** denotes the system-generated investor categorization output derived from the risk_questionnaire_total_score through algorithmic mapping logic whereby scores falling within the range of zero to thirty-five points inclusive are categorized as "Conservative," scores from thirty-six to sixty-five points inclusive are designated as "Balanced," and scores from sixty-six to one hundred points inclusive are classified as "Aggressive," with the resulting classification stored in the calculated_risk_profile field and serving as the primary reference parameter for all subsequent suitability matching operations and product recommendation constraints.

        **Product Risk Rating** signifies the standardized risk classification assigned to each investment product identified by product_code and product_name, expressed through a five-tier taxonomy comprising "Conservative," "Moderate," "Balanced," "Growth," and "Aggressive" designations, with the rating determined through quantitative analysis of historical volatility metrics, asset class composition, leverage factors, currency exposure, liquidity characteristics, and structural complexity, and permanently associated with each product record in the product master database to enable automated suitability comparison operations.

        **Suitability Check** represents the automated, real-time validation process executed by the Risk Engine middleware wherein the product_risk_rating of the selected investment instrument is algorithmically compared against the client's calculated_risk_profile using a hierarchical matching matrix such that a product rated "Conservative" is deemed suitable for all client risk profiles, "Moderate" products are suitable for "Balanced" and "Aggressive" profiles, "Balanced" products are suitable for "Balanced" and "Aggressive" profiles, "Growth" products are suitable only for "Aggressive" profiles, and "Aggressive" products are exclusively suitable for "Aggressive" client profiles, with the comparison outcome recorded as a boolean value in the suitability_check_passed field.

        **Suitability Mismatch** occurs when the hierarchical risk comparison logic determines that the product_risk_rating exceeds the permissible threshold relative to the client's calculated_risk_profile, triggering the suitability_mismatch_flag to assume a TRUE boolean state and initiating a mandatory exception workflow requiring the generation of a mismatch_waiver_document_id, explicit client acknowledgment of elevated risk exposure through documented signature, and supervisor_approval_required flag activation necessitating authorization from a supervisor_id personnel possessing appropriate delegation authority before transaction progression is permitted.

        **Net Asset Value (NAV)** constitutes the per-unit market valuation of a mutual fund investment product calculated by the fund administrator at the close of each trading day by dividing the total market value of all securities held within the fund portfolio, minus all liabilities and accrued expenses, by the total number of outstanding fund units, with the most recent NAV figure stored in the current_nav field and utilized as the basis for determining estimated_units to be allocated to the client through the mathematical operation of dividing the net_investment_amount by the current_nav with results typically expressed to two decimal places.

        **Front-End Load** refers to the sales charge or commission assessed at the point of initial investment purchase, expressed as a percentage of the gross subscription_amount in the front_end_load_percentage field, with the absolute dollar value of this charge computed as the product of subscription_amount multiplied by front_end_load_percentage divided by one hundred and recorded in the front_end_load_amount field, thereby reducing the actual capital deployed into the investment product which is represented by the net_investment_amount calculated as subscription_amount minus front_end_load_amount.

        **Annual Management Fee** represents the ongoing administrative and portfolio management charge levied by the fund house or investment manager, expressed as an annualized percentage rate in the annual_management_fee_percentage field, with the estimated first-year dollar impact calculated as net_investment_amount multiplied by annual_management_fee_percentage divided by one hundred and recorded in the annual_management_fee_amount field to provide clients with transparent disclosure of the recurring cost burden associated with the investment product over the holding period.

        **Straight-Through Processing (STP)** designates the operational paradigm wherein a transaction progresses from initial order entry by the Relationship Manager through all validation checkpoints, compliance screening layers, execution operations, and booking confirmations without requiring any manual intervention, data correction, exception handling, or workflow rerouting by Back Office Operations personnel, with achievement of this state indicated by the straight_through_processing_flag assuming a TRUE boolean value and serving as a key performance metric for operational efficiency measurement.

        **Cooling-Off Period** signifies a regulatory-mandated temporal interval during which a client who has authorized the purchase of a complex or high-risk structured product retains the unconditional right to cancel the transaction without incurring penalties, surrender charges, or adverse financial consequences, with the duration specified in hours within the cooling_off_period_hours field (typically twenty-four or forty-eight hours depending on product category and jurisdiction), and the transaction maintained in a "Pending_Cooling_Off" status within the transaction_status field until the designated period expires or the client exercises their cancellation right.

        **Audio-Video Recording (VR)** refers to the mandatory electronic capture, encryption, and archival of the complete sales interaction between the Relationship Manager and the client for transactions involving complex structured products where audio_video_recording_required assumes a TRUE boolean value, with each recording session assigned a unique audio_video_recording_id identifier and stored within the Sales Compliance Recording System (SCRS) for subsequent compliance review, quality assurance sampling, and regulatory audit purposes, ensuring complete documentation of risk disclosure script delivery and client verbal acknowledgment of understanding.

        **Trade Reference Number** constitutes the unique system-generated alphanumeric identifier assigned to each successfully executed investment transaction at the moment of order booking, stored in the trade_reference_number field, serving as the primary reference key for all downstream settlement operations, client confirmation communications, portfolio accounting entries, and regulatory transaction reporting obligations.

        **Contract Note Number** represents the specialized confirmation document identifier generated exclusively for structured product transactions processed through Treasury or Global Markets desks, stored in the contract_note_number field, containing comprehensive details including notional amount booked, strike price parameters, value date specifications, payoff scenario matrices, and counterparty information necessary for client record-keeping and regulatory compliance.

        4. Input

        The initiation of any investment transaction workflow governed by this Standard Operating Procedure requires the complete availability and validation of the following input data elements and contextual parameters drawn from multiple source systems and client interaction touchpoints. First, the transaction must be associated with a valid and active client_id representing a customer whose identity has been previously verified through government-issued identification documents and whose profile data is maintained within the Customer Relationship Management (CRM) system, including but not limited to client_name, client_age measured in integer years, client_annual_income declared in United States Dollar equivalents, client_net_worth representing total liquid and illiquid asset valuations, and client_investment_experience_years quantifying the duration of prior involvement with capital markets instruments. Second, the transaction must be originated and sponsored by an authorized relationship_manager_id whose relationship_manager_name, delegation authorities, and product certification credentials are recorded in the human resources and access control systems, with the initial transaction_timestamp capturing the precise date and time of workflow initiation in ISO 8601 format with timezone designation. Third, the client's settlement account infrastructure must be established with a valid settlement_account_number associated with the client_id and containing a verifiable available_balance in United States Dollar denomination sufficient to support the intended subscription_amount inclusive of all applicable fees and charges. Fourth, for transactions involving investment products, the system must have access to complete product master data including product_code, product_name, product_risk_rating, product_category classification (Mutual_Fund, Bond, Structured_Note, Dual_Currency_Investment, or Principal_Protected_Note), current_nav for unit-based instruments, front_end_load_percentage applicable to the specific client relationship tier, annual_management_fee_percentage as stipulated in the product prospectus, and disclosure_documents_presented list containing references to Fund_Fact_Sheet, Prospectus, Key Information Document (KID), and any supplementary risk disclosure materials. Fifth, the client's current compliance and eligibility status must be retrievable including the previous_risk_profile classification if any prior assessment exists, the previous_risk_profile_expiry_date indicating when the existing assessment loses validity, the aml_sanctions_screening_status reflecting the outcome of most recent sanctions list screening operations, the source_of_wealth_documented boolean flag indicating whether SOW documentation is on file, and the monitoring_threshold_amount parameter defining the trigger point for enhanced AML scrutiny which is standardly configured at one hundred thousand United States Dollars but may be adjusted based on client segment or regional regulatory requirements. Sixth, for structured products specifically, the input data must include the audio_video_recording_required boolean flag determined by product classification rules, the cooling_off_period_required flag indicating regulatory mandate applicability, and the cooling_off_period_hours duration specification. Seventh, the transaction must be tagged with operational metadata including branch_code identifying the originating business location, channel designation (Branch, Phone_Banking, Mobile_App, or Online_Banking), region code for geographic reporting purposes, and assignment of a compliance_officer_id responsible for oversight and exception review. Eighth, system access to market_data_source platforms such as Bloomberg or Reuters must be confirmed operational to enable real-time NAV verification, pricing validation, and market condition assessment. Finally, the client_authorization_method infrastructure must be configured and functional whether utilizing One-Time Password (OTP) delivery systems, biometric signature capture devices, physical signature verification protocols, or digital signature certificate frameworks to enable legally binding transaction consent capture with associated client_authorization_timestamp recording.

        5. Main Procedure

        5.1 Client Risk Profile Assessment and Establishment Phase

        5.1.1 Upon initiation of an investment transaction request or commencement of a new client investment relationship, the Relationship Manager designated by relationship_manager_id must first verify that the client identified by client_id possesses a current and valid risk profile by interrogating the CRM system to retrieve the previous_risk_profile classification and associated previous_risk_profile_expiry_date timestamp, comparing the expiry date against the current transaction_timestamp to determine temporal validity whereby if the previous_risk_profile_expiry_date is null indicating no prior assessment exists or if the previous_risk_profile_expiry_date precedes the current transaction_timestamp indicating expiry of the existing assessment, then the RM must initiate a complete Risk Tolerance Questionnaire administration workflow, whereas if a valid and unexpired previous_risk_profile exists then the RM may proceed directly to product selection and suitability validation stages while documenting the continued reliance on the existing risk categorization in the transaction audit trail.

        5.1.2 For scenarios requiring new or refreshed risk assessment, the Relationship Manager must administer the standardized Risk Tolerance Questionnaire instrument through either digital tablet-based presentation in branch environments or secure web-form delivery for remote channel transactions, ensuring the client personally completes all mandatory questions without RM influence or suggestion that might compromise assessment objectivity, with the questionnaire systematically collecting structured responses covering age bracket classification derived from client_age such that clients aged eighteen to thirty years receive zero baseline points, thirty-one to forty years receive five points, forty-one to fifty years receive ten points, fifty-one to sixty years receive fifteen points, and sixty-one years or greater receive twenty points reflecting increasing conservative orientation with age; income stability evaluation based on client_annual_income and employment sector whereby salaried employees in stable industries receive fifteen points, self-employed or commission-based income sources receive ten points, and retired individuals with fixed income streams receive twenty points; investment time horizon assessment whereby horizons less than one year receive zero points, one to three years receive ten points, three to five years receive fifteen points, five to ten years receive twenty points, and greater than ten years receive twenty-five points reflecting capacity to weather market volatility; loss tolerance psychological evaluation presented through scenario-based questions whereby willingness to accept potential loss of zero to five percent over one year receives five points, five to fifteen percent tolerance receives fifteen points, fifteen to thirty percent tolerance receives twenty-five points, and acceptance of greater than thirty percent loss potential receives thirty points; and prior investment experience scoring wherein client_investment_experience_years of zero years receives zero points, one to three years receives five points, four to seven years receives ten points, eight to fifteen years receives fifteen points, and greater than fifteen years receives twenty points, with all individual question responses recorded in JSON format within the risk_questionnaire_responses field maintaining complete granular detail for audit and quality review purposes.

        5.1.3 Upon completion of questionnaire data capture, the Risk Engine component of the Wealth Management System must aggregate all individual question scores to compute the risk_questionnaire_total_score as an integer summation ranging from zero to one hundred points, subsequently applying deterministic mapping logic to derive the calculated_risk_profile classification such that total scores in the range zero through thirty-five points inclusive result in "Conservative" classification reflecting low risk tolerance, preference for capital preservation, and suitability primarily for fixed income and money market instruments; scores in the range thirty-six through sixty-five points inclusive result in "Balanced" classification indicating moderate risk tolerance, acceptance of measured volatility, and suitability for diversified portfolios combining equity and fixed income exposures; and scores in the range sixty-six through one hundred points inclusive result in "Aggressive" classification signifying high risk tolerance, focus on capital appreciation over income generation, and suitability for concentrated equity positions, alternative investments, and complex structured products, with the calculated_risk_profile value recorded in the designated field and simultaneously triggering system updates to the client's master profile record in the CRM database.

        5.1.4 The system must automatically present the calculated_risk_profile classification to the client through the RM's interface along with a comprehensive narrative description explaining the characteristics, typical investment strategies, and product categories associated with the determined profile, requiring explicit client acknowledgment through one of the configured client_authorization_method protocols such that if the client agrees with the calculated classification they must provide affirmative consent via OTP validation, biometric signature capture, physical signature on printed assessment summary, or digital signature application with the client_authorization_timestamp precisely recorded, whereas if the client disputes the calculated classification expressing belief that their risk tolerance is either higher or lower than the system determination, the RM must initiate a documented re-evaluation workflow involving completion of a supplementary questionnaire with additional scenario-based questions, consultation with an Investment Product Specialist referenced by IPS identifier for expert second opinion, and mandatory submission of written justification narrative explaining the basis for override request which is subject to compliance_officer_id review and approval before an adjusted calculated_risk_profile may be recorded in the system with all override documentation forming part of the permanent client file.

        5.1.5 Following successful client acceptance and authorization of the calculated_risk_profile, the system must automatically compute the risk_profile_expiry_date by adding a duration of exactly seven hundred thirty days (equivalent to two calendar years) to the current transaction_timestamp to establish the validity period for the assessment, update the client's master record in the CRM with the new calculated_risk_profile value replacing any previous_risk_profile designation, set the risk_profile_expiry_date in the client profile, and most critically modify the client's investable_status field to assume the value "Active" thereby removing any systemic blocks that would prevent investment transaction processing and enabling the client to proceed with product purchases within their suitability parameters, while also triggering automated calendar reminders to the assigned relationship_manager_id at intervals of sixty days prior to expiry, thirty days prior to expiry, and at expiry date to ensure proactive risk profile renewal before eligibility lapses and transactions become blocked.

        5.2 Investment Product Selection and Suitability Validation Phase

        5.2.1 With a valid and active calculated_risk_profile established and the investable_status confirmed as "Active," the Relationship Manager must proceed to product recommendation and selection activities by first retrieving from the product master database all investment instruments whose product_risk_rating falls within the permissible range aligned with the client's calculated_risk_profile utilizing the hierarchical suitability matrix logic whereby clients with "Conservative" calculated profiles may only be presented products rated "Conservative" or "Moderate," clients with "Balanced" calculated profiles may be presented products rated "Conservative," "Moderate," or "Balanced," and clients with "Aggressive" calculated profiles may be presented products across all rating categories including "Conservative," "Moderate," "Balanced," "Growth," and "Aggressive," with the RM particularly focusing recommendation efforts on products generating optimal fee-based revenue through front_end_load_percentage and annual_management_fee_percentage structures while remaining within client suitability constraints and appropriateness for the client's stated investment objectives, time horizon, and current portfolio composition.

        5.2.2 Upon identifying a specific target product characterized by product_code, product_name, product_category, and product_risk_rating, the Relationship Manager must conduct a comprehensive product presentation session with the client encompassing mandatory disclosure of all material information contained within the regulatory-required disclosure_documents_presented list, specifically including the Fund Fact Sheet containing one-page summary of investment objective, asset allocation strategy, historical performance metrics for one-year, three-year, five-year, and since-inception periods with explicit disclaimer that past performance does not guarantee future results, the complete Prospectus or offering document detailing investment policies, restrictions, risk factors, management team biographies, and financial statements, and the Key Information Document (KID) formatted in standardized layout presenting objectives, risk and reward profile using the Synthetic Risk and Reward Indicator (SRRI) scale, cost disclosures showing reduction in yield due to charges, and performance scenarios under stressed, unfavorable, moderate, and favorable market conditions, with the RM required to explicitly draw client attention to the product_risk_rating classification, the front_end_load_percentage expressed both as percentage rate and absolute dollar amount calculated as subscription_amount multiplied by front_end_load_percentage divided by one hundred, the annual_management_fee_percentage similarly expressed in both percentage and estimated annual dollar impact, and specific sections of the risk disclosure content addressing market risk, credit risk for fixed income products, currency risk for internationally-invested funds, liquidity risk, and concentration risk where applicable.

        5.2.3 For transactions involving structured products where product_category is designated as "Structured_Note," "Dual_Currency_Investment," or "Principal_Protected_Note," additional procedural requirements beyond standard mutual fund disclosure become mandatory, specifically requiring the Relationship Manager to conduct a detailed payoff scenario analysis presentation utilizing market data sourced from the designated market_data_source platform such as Bloomberg or Reuters to demonstrate to the client through numerical examples and graphical illustrations how the structured product's return profile varies under different market conditions, for instance explaining that a Dual Currency Investment may deliver a five percent coupon if the underlying exchange rate remains above a specified strike level at maturity but could result in principal repayment in a depreciated foreign currency if the strike is breached thereby crystallizing foreign exchange loss, and for any structured product transaction where audio_video_recording_required assumes TRUE boolean value indicating regulatory mandate for sales process documentation, the RM must activate the Sales Compliance Recording System (SCRS) to capture complete audio and video recording of the presentation and client interaction, with the system generating a unique audio_video_recording_id identifier that becomes permanently associated with the transaction_id and stored in encrypted format on secure archival storage infrastructure for minimum retention periods typically extending seven years to satisfy regulatory audit and examination requirements.

        5.2.4 Following completion of all mandatory disclosure presentations and client review of documentation, the Relationship Manager must proceed to formal order entry by accessing the Wealth Management System's transaction module and creating a new transaction record populated with transaction_id generated through system-assigned sequential alphanumeric format (e.g., INV_YYYYMMDDNNNNN), capturing the current transaction_timestamp with precision to the second in UTC format, associating the client_id and relationship_manager_id with the transaction, specifying the transaction_type as "Risk_Profiling" if this is solely a profile establishment transaction, "Mutual_Fund_Subscription" for open-ended fund purchases, or "Structured_Product_Enrollment" for complex instrument bookings, recording the selected product_code and confirming automatic population of related product_name, product_risk_rating, product_category, current_nav for NAV-based funds, front_end_load_percentage, and annual_management_fee_percentage from the product master database, capturing the client's desired subscription_amount in United States Dollar value, identifying the designated settlement_account_number from which funds will be debited, and tagging the transaction with branch_code, channel, region, and assigned compliance_officer_id based on transaction value thresholds and risk characteristics of the product.

        5.2.5 At the moment of order entry completion but prior to final client authorization and execution, the Wealth Management System must invoke its integrated Risk Engine middleware to perform automated suitability validation by executing a comparative evaluation between the product_risk_rating of the selected investment instrument and the client's established calculated_risk_profile using the hierarchical matching algorithm such that the suitability_check_passed field assumes TRUE boolean value if the product rating is equal to or lower than the client profile on the Conservative-Moderate-Balanced-Growth-Aggressive hierarchy (specifically: Conservative products pass for all profiles; Moderate products pass for Balanced and Aggressive profiles; Balanced products pass for Balanced and Aggressive profiles; Growth products pass only for Aggressive profiles; Aggressive products pass only for Aggressive profiles), whereas if the product_risk_rating is hierarchically superior to the client's calculated_risk_profile indicating a suitability violation, the suitability_check_passed field assumes FALSE boolean value and the suitability_mismatch_flag is set to TRUE triggering immediate workflow diversion to an exception handling process that displays a hard-block error message to the Relationship Manager preventing order progression unless the RM initiates a formal Risk Mismatch Waiver procedure requiring generation of a mismatch_waiver_document_id identifier, electronic or physical presentation of a standardized waiver form to the client explicitly stating in clear and unambiguous language that the recommended product exceeds the client's assessed risk tolerance and may result in investment losses greater than the client indicated willingness to accept during risk profiling, capture of client signature acknowledging and accepting the elevated risk exposure and confirming understanding that they are proceeding against the bank's standard suitability recommendation, and critically the activation of supervisor_approval_required flag to TRUE boolean state necessitating routing of the transaction to a supervisory personnel identified by supervisor_id possessing appropriate delegation authority who must review the complete risk assessment documentation, product disclosure records, waiver acknowledgment, and RM justification narrative before either approving the transaction which permits continuation to execution or rejecting the transaction which terminates the workflow and requires the RM to recommend an alternative suitable product to the client.

        5.3 Pre-Trade Compliance and Financial Validation Phase

        5.3.1 For all transactions regardless of product type where the suitability_check_passed field confirms TRUE boolean value either through direct matching or through approved supervisor override following mismatch waiver procedures, the system must proceed to execute comprehensive pre-trade compliance screening operations beginning with Anti-Money Laundering (AML) sanctions list verification by interfacing with the bank's enterprise AML monitoring platform to submit the client_id, client_name, and transaction details for real-time screening against all relevant sanctions lists including OFAC (Office of Foreign Assets Control) Specially Designated Nationals (SDN) list, EU consolidated sanctions list, UN Security Council sanctions designations, and national sanctions registries applicable to the bank's operating jurisdictions, with the screening outcome recorded in the aml_sanctions_screening_status field assuming values of "Clear" if no matches are detected indicating permission to proceed, "Flagged" if potential name matches or watchlist hits are identified requiring immediate escalation to the compliance_officer_id for manual review and disposition decision before transaction can advance, or maintaining "Pending" status during the interval while screening systems process the query with typical resolution timeframes under five seconds for unambiguous clear results.

        5.3.2 Concurrent with AML sanctions screening, the system must evaluate whether the transaction subscription_amount exceeds the configured monitoring_threshold_amount parameter which is standardly established at one hundred thousand United States Dollars (100000.00) for retail wealth management transactions, setting the transaction_threshold_exceeded field to TRUE boolean value when subscription_amount is strictly greater than monitoring_threshold_amount, and when this threshold breach condition is detected, the system must automatically verify that the source_of_wealth_documented field associated with the client_id assumes TRUE boolean value indicating that current and valid Source of Wealth (SOW) documentation such as employment contracts, business ownership records, inheritance documentation, real estate sale proceeds verification, or investment portfolio liquidation statements have been collected and verified by the compliance team and are stored in the document management system, such that if source_of_wealth_documented is FALSE when transaction_threshold_exceeded is TRUE, the system must generate a hard-block preventing transaction execution and display to the Relationship Manager explicit instruction that SOW documentation must be obtained, submitted for compliance review, and approved before the transaction can proceed with the workflow entering suspended state pending documentation completion.

        5.3.3 Following successful completion of AML screening yielding "Clear" status and confirmation of SOW documentation adequacy for threshold-exceeding transactions, the system must proceed to funds availability verification by executing a real-time balance inquiry against the Core Banking System using the settlement_account_number to retrieve the current available_balance in United States Dollar equivalents, comparing this available_balance against the required subscription_amount to determine sufficiency such that the funds_availability_verified field assumes TRUE boolean value only when available_balance is greater than or equal to subscription_amount thereby confirming that adequate liquid funds exist to settle the transaction without creating overdraft conditions or requiring supplementary funding arrangements, whereas if available_balance is less than subscription_amount indicating insufficient funds, the funds_availability_verified field assumes FALSE boolean value triggering generation of an insufficient funds notification to the Relationship Manager who must either arrange for the client to transfer additional funds into the settlement_account_number before proceeding or reduce the subscription_amount to fit within the available_balance constraint with the revised amount requiring fresh suitability validation if the reduction is substantial enough to change fee structures or minimum investment thresholds.

        5.3.4 Aggregating all component validation outcomes, the system must compute an overall pre_trade_compliance_passed field assuming TRUE boolean value only when all of the following conditions are simultaneously satisfied: suitability_check_passed equals TRUE (either directly or through approved override), aml_sanctions_screening_status equals "Clear," if transaction_threshold_exceeded equals TRUE then source_of_wealth_documented must equal TRUE, and funds_availability_verified equals TRUE, such that failure of any single validation component results in pre_trade_compliance_passed assuming FALSE boolean value and preventing workflow advancement to execution stages, with the system generating detailed diagnostic messages identifying which specific validation component failed to enable the Relationship Manager to take corrective action such as obtaining missing SOW documentation, waiting for funds transfer completion, or selecting an alternative product that passes suitability requirements.

        5.3.5 For mutual fund transactions specifically where product_category equals "Mutual_Fund" and pre_trade_compliance_passed confirms TRUE boolean value, the system must proceed to calculate precise financial metrics beginning with computation of the front_end_load_amount expressed in United States Dollars by multiplying the subscription_amount by the product's front_end_load_percentage and dividing by one hundred with results rounded to two decimal places using standard banker's rounding convention (round half to even), subsequently calculating the net_investment_amount representing the actual capital deployed into the fund by subtracting the front_end_load_amount from the subscription_amount, utilizing the current_nav value retrieved from the product master database (which itself is updated nightly through automated feeds from fund administrators or sourced real-time from market_data_source platforms during trading hours) to compute the estimated_units that will be allocated to the client's portfolio by dividing the net_investment_amount by the current_nav with precision extended to four decimal places to ensure accurate unit allocation given that mutual fund units are typically fractional, and additionally calculating an estimated annual_management_fee_amount by multiplying the net_investment_amount by the annual_management_fee_percentage and dividing by one hundred to project the first year's ongoing fee burden, with all calculated financial metrics recorded in their respective fields and presented to the client in a comprehensive Fee Impact Sheet disclosure summary enabling transparent understanding of all costs associated with the investment prior to final authorization.

        5.4 Client Authorization and Transaction Execution Phase

        5.4.1 With all pre-trade compliance validations successfully passed yielding pre_trade_compliance_passed equals TRUE and all financial calculations completed including front_end_load_amount, net_investment_amount, estimated_units, and annual_management_fee_amount determined and disclosed, the Relationship Manager must present the complete transaction summary to the client for final review and authorization, utilizing the Wealth Management System's transaction preview interface to display a consolidated summary screen showing the product_name, subscription_amount, front_end_load_amount with explicit notation of the percentage and dollar impact, net_investment_amount representing actual capital invested, estimated_units based on current_nav with clear disclaimer that final unit allocation will be determined based on the official NAV calculated at the close of business on the transaction date which may differ from the estimated NAV displayed, annual_management_fee_amount with explanation of ongoing fee structure, settlement_account_number from which funds will be debited, expected settlement_date typically following T+1 (trade date plus one business day) or T+2 settlement cycles depending on product category and fund house processing rules, and all relevant risk disclosures and terms and conditions, requiring the client to explicitly confirm their understanding and acceptance of all displayed terms before authorization is granted.

        5.4.2 Upon client confirmation of transaction review and expression of intent to proceed, the system must invoke the configured client_authorization_method framework to capture legally binding consent whereby if the method is designated as "OTP" (One-Time Password), the system generates a six-digit numerical code transmitted to the client's registered mobile telephone number via SMS or banking application push notification requiring the client to manually enter the received code into the transaction interface within a validity window of three hundred seconds (five minutes) before code expiration; if the method is "Biometric" the system interfaces with fingerprint scanner, facial recognition camera, or iris scanning hardware to capture the client's biometric signature comparing the captured template against the reference template stored during account opening with matching threshold typically set at ninety-five percent confidence level or higher; if the method is "Physical_Signature" the client must apply their handwritten signature to a printed transaction document or deal ticket with the RM verifying signature consistency against the specimen signature on file; or if the method is "Digital_Signature" the client utilizes their personal digital certificate issued under Public Key Infrastructure (PKI) framework to cryptographically sign the transaction data creating a non-repudiable authorization record, with the successful completion of authorization via any of these methods recorded by capturing the precise client_authorization_timestamp in ISO 8601 format with timezone and millisecond precision establishing the exact moment of legally binding consent.

        5.4.3 Immediately following successful client authorization capture, the system must evaluate whether the transaction involves a structured product requiring a regulatory cooling-off period by examining the cooling_off_period_required boolean field, such that for transactions where cooling_off_period_required equals FALSE (typically mutual fund and standard bond purchases), the system proceeds directly to immediate execution operations, whereas for transactions where cooling_off_period_required equals TRUE (typically structured notes, dual currency investments, and principal protected notes in jurisdictions mandating investor protection cooling-off rights), the system must divert the transaction to a deferred execution workflow by setting the transaction_status field to "Pending_Cooling_Off," recording the cooling_off_period_hours duration (commonly twenty-four or forty-eight hours depending on product complexity and local regulations), calculating a cooling-off expiry timestamp by adding the cooling_off_period_hours to the client_authorization_timestamp thereby establishing the earliest moment at which execution may proceed, and placing the transaction into an automated batch queue monitored by scheduled system jobs that execute at hourly intervals to identify all transactions whose cooling-off expiry timestamp has passed and whose status indicates no client cancellation request has been received, at which point the system automatically updates transaction_status from "Pending_Cooling_Off" to "Ready_for_Execution" and routes the transaction to the appropriate execution subsystem.

        5.4.4 For transactions where cooling-off requirements are not applicable or where the cooling-off period has successfully elapsed without client cancellation, the system must proceed to transaction execution operations which vary based on product_category such that for product_category equal to "Mutual_Fund," the Wealth Management System interfaces with the fund house order routing gateway to transmit an electronic purchase order containing the client_id mapped to the fund house's investor account number, product_code mapped to the fund's ISIN or local fund identifier, net_investment_amount as the subscription value, estimated_units for reference purposes with notation that final allocation will be NAV-based, settlement_account_number details for fund receipt, and transaction_timestamp establishing trade date, with the fund house's automated order management system acknowledging receipt and returning a preliminary order confirmation that the system stores as the trade_reference_number serving as the primary tracking identifier for all downstream settlement and reconciliation activities; whereas for product_category equal to "Structured_Note," "Dual_Currency_Investment," or "Principal_Protected_Note," the Wealth Management System creates a structured product order record and transmits this via secure messaging protocols to the bank's Treasury or Global Markets desk which functions as the internal counterparty or arranger for such instruments, with the Treasury desk's trading personnel reviewing the order parameters including notional amount, tenor, strike prices, barrier levels, and underlying asset specifications before manually confirming acceptance and execution which triggers generation of a contract_note_number representing the formal trade confirmation documentation that includes all economic terms, value_date establishing when the structured note becomes effective, pricing parameters, and payoff formulas that the system associates with the transaction record.

        5.4.5 Concurrent with order transmission to external fund houses or internal Treasury desks, the system must execute settlement account debit operations by generating an immediate debit instruction to the Core Banking System specifying the settlement_account_number, the full subscription_amount (not merely net_investment_amount, as the gross amount including fees must be debited), a descriptive narration field containing transaction_id and product_name for client statement clarity, and value date designation matching the transaction execution date, with the Core Banking System returning a debit confirmation reference number that validates successful fund reservation or movement from available balance to blocked or transit status pending final settlement with the fund house or product issuer, and upon successful debit confirmation, the system updates the available_balance field in the transaction record to reflect the post-transaction balance status, sets the transaction_status field to "Executed" indicating successful completion of all execution operations, records the execution_timestamp capturing the exact date and time when execution operations concluded, calculates the settlement_date based on product-specific settlement cycles (T+1 for most mutual funds, T+2 for certain offshore funds, T+0 or T+1 for structured products depending on Treasury desk processing), and critically evaluates whether the entire transaction lifecycle from initiation through execution occurred without any manual intervention, exception handling, workflow rerouting, or data correction by setting the straight_through_processing_flag to TRUE only when zero manual touchpoints occurred or to FALSE if any Operations or Compliance personnel intervened at any stage thereby providing key operational efficiency metrics.

        5.5 Post-Execution Compliance Review and Documentation Phase

        5.5.1 Following successful transaction execution with transaction_status updated to "Executed" and all primary processing operations completed, the system must automatically route a subset of transactions to mandatory post-execution compliance review based on risk-based selection criteria whereby all transactions where audio_video_recording_required equals TRUE indicating complex product sales must be queued for compliance review, all transactions where suitability_mismatch_flag equals TRUE indicating risk override scenarios must be reviewed, all transactions where transaction_threshold_exceeded equals TRUE indicating large-value orders must be sampled, and additionally a statistically random sample of standard transactions equating to typically five percent of daily transaction volume must be selected to ensure ongoing quality monitoring of routine sales practices, with all selected transactions routed to the assigned compliance_officer_id whose workqueue interface displays the transaction details, provides direct playback access to audio_video_recording_id files where applicable, presents the complete audit trail of system decision points and validation outcomes, and enables the compliance officer to review for potential process violations, documentation deficiencies, inadequate risk disclosure, or signs of client pressure or miss-selling behaviors.

        5.5.2 The assigned Compliance Officer executing post-trade review must systematically evaluate each transaction against a standardized compliance checklist covering verification that disclosure_documents_presented list includes all mandatory materials appropriate to the product_category, confirmation that client_authorization_timestamp exists and authorization method was properly executed, validation that for any suitability_mismatch_flag equals TRUE scenario the associated mismatch_waiver_document_id is present and supervisor_approval_timestamp confirms supervisory review occurred, assessment of audio_video_recording_id content where applicable to verify that the Relationship Manager delivered the mandatory risk disclosure script in clear and comprehensible language without minimizing downside scenarios and that the client verbally acknowledged understanding without evidence of confusion or hesitation that might suggest insufficient comprehension, and evaluation of overall transaction coherence relative to client_age, client_annual_income, client_net_worth, and stated investment objectives to identify potentially unsuitable sales that passed automated screening but exhibit qualitative concerns, with the outcome of this review process documented through entry of compliance_review_notes text field containing detailed observations and conclusions, and critically the setting of compliance_defect_flag to TRUE boolean value if any material deficiencies are identified that constitute process violations requiring corrective action or to FALSE if the transaction is determined fully compliant with all regulatory and internal policy requirements.

        5.5.3 For any transaction where compliance_defect_flag assumes TRUE boolean value indicating identification of process violations or documentation deficiencies, the Compliance Officer must initiate corrective action workflows which may include requiring the Relationship Manager to obtain supplementary documentation from the client such as additional risk acknowledgment forms or missing SOW records, scheduling a mandatory follow-up client contact to address disclosure gaps or confirm understanding of product risks that may not have been adequately communicated during initial sale, imposing transaction reversal or cancellation where severe suitability violations or material misrepresentation is identified within allowable reversal timeframes typically extending three to five business days post-execution, generating formal incident reports that are escalated to senior management and legal/compliance committees documenting the nature of the defect and remediation actions taken, and where patterns of defects are associated with specific relationship_manager_id personnel, triggering performance management interventions ranging from mandatory retraining on product knowledge and sales process requirements to suspension of investment sales privileges pending demonstration of competency improvement, with all corrective actions tracked through case management systems and recorded in the transaction_id audit trail to establish complete regulatory accountability.

        5.5.4 Parallel to compliance review processes, the Operations or Back Office team identified by operational processing queues must execute post-execution reconciliation and settlement monitoring activities by comparing the trade_reference_number or contract_note_number generated during execution against subsequent confirmation messages received from fund houses, custodian banks, or internal Treasury systems to verify that external parties have accurately booked the transaction with matching details including client account references, product identifiers, subscription amounts, unit allocations based on official NAV calculations, and settlement_date expectations, with any discrepancies between internally recorded transaction parameters and external confirmations flagged as exceptions requiring investigation and resolution through formal breaks management processes that may involve contacting fund house operations teams, submitting transaction amendment requests, or in severe cases unwinding and rebooking transactions to correct errors, and once full reconciliation is achieved confirming that the estimated_units calculated during pre-execution based on preliminary current_nav align within acceptable tolerance ranges (typically plus or minus zero point five percent) with the final units allocated by the fund house based on official end-of-day NAV calculations, the Operations team updates the transaction record with final unit quantities and confirms that settlement accounting entries have been accurately posted to both the client's investment portfolio custody account and the bank's omnibus accounts with external fund houses or custodians.

        5.5.5 As the culminating step of the post-execution phase, the system must generate comprehensive client confirmation documentation by producing a trade confirmation letter or contract note that includes transaction_id for reference, client_name and client_id for identification, product_name and product_code for clarity on what was purchased, subscription_amount showing the total funds committed, front_end_load_amount transparently disclosing upfront fees charged, net_investment_amount showing capital actually deployed, estimated_units allocated pending final NAV confirmation with explicit notation that final unit allocation may vary slightly, current_nav used for estimation purposes, settlement_date indicating when the transaction will be finalized, settlement_account_number debited, trade_reference_number or contract_note_number for tracking purposes, comprehensive fee disclosures reiterating both front_end_load_percentage and annual_management_fee_percentage with projected annual_management_fee_amount, and regulatory disclosures including cooling-off rights if applicable, complaint procedures, and investor protection scheme information, with this confirmation document delivered to the client through their preferred communication channel whether postal mail, secure email, mobile application notification, or online banking message center within the regulatory-mandated timeframe typically requiring delivery within one business day of execution, and the system records the confirmation delivery timestamp and method to demonstrate compliance with client communication obligations, simultaneously calculating the total_processing_time_minutes field by computing the elapsed time in minutes between the original transaction_timestamp when the process initiated and the execution_timestamp when execution operations completed, providing a quantitative metric of processing efficiency that feeds into operational dashboards tracking cycle times and identifying process bottlenecks requiring optimization attention.

        6. Output

        Upon successful completion of all procedural stages encompassing Risk Profile Assessment and Establishment, Investment Product Selection and Suitability Validation, Pre-Trade Compliance and Financial Validation, Client Authorization and Transaction Execution, and Post-Execution Compliance Review and Documentation, the Banking Invest Process produces a comprehensive set of deterministic outputs recorded within the transaction data structure and associated systems enabling full auditability and operational measurement. The primary quantitative outputs include the calculated_risk_profile classification assuming one of three discrete values ("Conservative," "Balanced," or "Aggressive") derived through algorithmic scoring of risk_questionnaire_total_score with the corresponding risk_profile_expiry_date timestamp establishing validity period, the investable_status field updated to "Active" enabling future transaction processing, the suitability_check_passed boolean definitively indicating whether product selection aligns with client risk parameters, the pre_trade_compliance_passed boolean aggregating all validation outcomes, the precise financial calculations comprising front_end_load_amount expressed in United States Dollars with two decimal precision, net_investment_amount representing actual invested capital, estimated_units calculated to four decimal precision through NAV-based division, and annual_management_fee_amount projecting ongoing cost burden. Transaction execution outputs include the system-generated trade_reference_number or contract_note_number serving as permanent tracking identifiers, the definitive transaction_status value progressing through state transitions from "Pending" through "Pending_Cooling_Off" if applicable to final "Executed" state for successful completions or "Cancelled" or "Failed" states for unsuccessful outcomes, the execution_timestamp providing precise temporal record of transaction consummation, the settlement_date establishing when final settlement will occur typically following T+1 or T+2 cycles, and the straight_through_processing_flag boolean indicating whether zero-touch processing was achieved contributing to STP rate metrics calculated as the percentage of transactions with this flag set to TRUE. Compliance and quality outputs encompass the compliance_defect_flag boolean identifying transactions requiring corrective action, the detailed compliance_review_notes text field documenting officer observations, the supervisor_approval_timestamp for escalated transactions requiring management authorization, and the audio_video_recording_id providing immutable evidence of sales process execution for complex products. Operational efficiency metrics output includes the total_processing_time_minutes integer value enabling calculation of average cycle time performance indicators, the funds_availability_verified boolean confirming settlement readiness, and the available_balance post-transaction value enabling liquidity monitoring. Risk control outputs definitively record the suitability_mismatch_flag boolean and associated mismatch_waiver_document_id for exception tracking, the aml_sanctions_screening_status confirming compliance with sanctions regulations, the source_of_wealth_documented boolean validating enhanced due diligence for high-value transactions, and the transaction_threshold_exceeded flag identifying transactions subject to enhanced monitoring. Collectively these outputs enable computation of key performance indicators including Sales Conversion Rate calculated as (count of transactions with transaction_status equals "Executed") divided by (count of all initiated transactions) multiplied by one hundred percent, Straight-Through Processing Rate calculated as (count of transactions with straight_through_processing_flag equals TRUE) divided by (count of transactions with transaction_status equals "Executed") multiplied by one hundred percent, Suitability Pass Rate calculated as (count of transactions with suitability_check_passed equals TRUE and suitability_mismatch_flag equals FALSE) divided by (count of all transactions) multiplied by one hundred percent, Average Ticket Size calculated as sum of all subscription_amount values divided by count of executed transactions, Compliance Defect Ratio calculated as (count of transactions with compliance_defect_flag equals TRUE) divided by (count of transactions reviewed by compliance) multiplied by one hundred percent, and Average Processing Time calculated as mean of all total_processing_time_minutes values across executed transactions, with all metrics stored in data warehouse structures enabling trend analysis, performance benchmarking against industry standards, identification of process improvement opportunities, and regulatory reporting demonstrating adherence to investor protection obligations and operational excellence standards mandated by banking supervisory authorities.

        </SOP>'''
    additional_context = '''
    ### 1. Business Overview
    - **Scenario Name:** Retail Wealth Management & Investment Product Subscription
    - **Industry:** Banking & Financial Services
    - **Primary Purpose / Value:** To facilitate the purchase and allocation of investment products (such as mutual funds, bonds, and structured deposits) for retail and high-net-worth clients, ensuring regulatory compliance (KYC/AML) while maximizing assets under management (AUM) and fee-based revenue for the bank.

    ### 2. Business Types
    - **Sub-business A: Risk Profiling & Investor Suitability Assessment:** The foundational process of determining a client's risk tolerance, financial situation, and investment knowledge before they can purchase any product.
    - **Sub-business B: Mutual Fund Subscription (Lump Sum):** The direct purchase of open-ended mutual fund units by a client using available funds in their savings account.
    - **Sub-business C: Structured Product Enrollment:** The sales and setup process for complex financial instruments (e.g., Dual Currency Investments or Principal Protected Notes) requiring specific disclosures and cooling-off periods.

    ### 3. Process Description

    - **Sub-business A Process: Risk Profiling & Investor Suitability Assessment**
        1)  **Step 1: Client Identification:** The Relationship Manager (RM) verifies the client's identity using government-issued ID and retrieves the client's current profile from the CRM.
        2)  **Step 2: Questionnaire Administration:** The client completes a regulatory-mandated "Risk Tolerance Questionnaire" (digital or paper-based) covering age, income, investment experience, and liquidity needs.
        3)  **Step 3: Scoring & Categorization:** The system calculates a total score based on the answers and maps the client to a specific Risk Profile (e.g., Conservative, Balanced, Aggressive).
        4)  **Step 4: Acknowledgment & Confirmation:** The client reviews the calculated risk level. If they agree, they digitally sign the assessment. If they disagree, a re-evaluation process is triggered with documented justification.
        5)  **Step 5: Validity Setting:** The system sets an expiration date for the assessment (typically 1-2 years) and updates the client's "Investable Status" flag to "Active."

    - **Sub-business B Process: Mutual Fund Subscription (Lump Sum)**
        1)  **Step 1: Product Selection:** Based on the client's Risk Profile, the RM recommends a specific mutual fund (e.g., "Global Tech Growth Fund"). The system verifies that the product's risk rating does not exceed the client's risk tolerance.
        2)  **Step 2: Fact Sheet & Disclosure Presentation:** The RM presents the Fund Fact Sheet, Prospectus, and Key Information Document (KID) to the client, highlighting fees, past performance, and risks.
        3)  **Step 3: Order Entry:** The RM enters the subscription amount (e.g., $50,000), the fund code, and the fee structure (front-end load discount, if applicable) into the Investment Order System.
        4)  **Step 4: Pre-Trade Compliance Check:** The system performs real-time checks for funds availability, AML sanctions screening, and suitability matching.
        5)  **Step 5: Client Authorization:** The client authorizes the transaction via a secure method (OTP, biometric signature, or physical signature on a deal ticket).
        6)  **Step 6: Transaction Execution:** The system debits the client's settlement account and generates a "Trade Reference Number" and "Estimated Units" based on the last known NAV (Net Asset Value).

    - **Sub-business C Process: Structured Product Enrollment**
        1)  **Step 1: Product Pitch & Scenario Analysis:** The RM explains the payoff scenarios of a structured note (e.g., "If Stock X stays above $100, you get 5% coupon; if it drops, capital is at risk").
        2)  **Step 2: Audio/Video Recording (VR):** For complex products, regulations often require the sales process to be recorded. The RM initiates the VR system, clearly stating the product risks and obtaining client verbal consent.
        3)  **Step 3: Cooling-Off Period Setup:** The RM inputs the order. Unlike mutual funds, the system places the order in a "Pending Cooling-Off" status (e.g., 24 hours), during which the client can cancel without penalty.
        4)  **Step 4: Final Confirmation:** After the cooling-off period expires, the system automatically checks for cancellation requests. If none, the order status changes to "Ready for Execution."
        5)  **Step 5: Order Batched for Treasury:** The system aggregates the order with others and transmits a buy order to the Bank's Treasury/Global Markets desk.
        6)  **Step 6: Booking Confirmation:** The Treasury desk confirms the strike price and value date. The system generates a "Contract Note Number" and "Notional Amount Booked."

    ### 4. Key Roles and Responsibilities
    - **Relationship Manager (RM):** Responsible for client consultation, product recommendation, conducting risk assessments, and ensuring the "Suitability" of products sold.
    - **Client:** Responsible for providing accurate financial information, reviewing disclosure documents, and authorizing transactions.
    - **Investment Product Specialist (IPS):** Subject matter expert who supports the RM in explaining complex products and assists in portfolio construction.
    - **Compliance Officer:** Reviews high-risk transactions, monitors audio/video recordings for miss-selling, and ensures adherence to regulatory guidelines.
    - **Operations/Back Office:** Handles the reconciliation of trades, settlement of funds, and communication with fund houses or custodians.

    ### 5. System and Tool Support
    - **Wealth Management System (WMS):** The core platform for managing client portfolios, executing trades, and storing product data.
    - **CRM (Customer Relationship Management):** Stores client KYC data, interaction logs, and triggers for risk profile renewals.
    - **Sales Compliance Recording System (SCRS):** A specialized tool for recording, encrypting, and archiving audio/video interactions during the sales process.
    - **Risk Engine:** An automated middleware that compares Client Risk Scores against Product Risk Ratings to prevent non-compliant sales (Hard blocking).
    - **Market Data Terminal (e.g., Bloomberg/Reuters):** Used by RMs and IPSs to view real-time pricing, NAVs, and market news.

    ### 6. Risks and Control Points
    - **Risk Point 1: Miss-selling (Suitability Risk)**
        - *Description:* Selling a high-risk product to a conservative investor.
        - *Control Measures:* Automated system hard-blocks preventing order entry if (Product Risk > Client Risk) unless a specific "Mismatch Form" is signed and approved by a supervisor.
    - **Risk Point 2: Money Laundering (AML Risk)**
        - *Description:* Large lump sum investments used to layer illicit funds.
        - *Control Measures:* Real-time transaction monitoring triggers for amounts exceeding a threshold (e.g., $100,000) requiring Source of Wealth (SOW) documentation upload before trade execution.
    - **Risk Point 3: Operational Failure (Trade Error)**
        - *Description:* Entering the wrong fund code or amount.
        - *Control Measures:* "Four-eye principle" (Maker-Checker) requirement for transactions above a certain value; mandatory read-back of order details to the client before final confirmation.
    - **Risk Point 4: Failure to Disclose Risks**
        - *Description:* Client not fully understanding the capital-at-risk nature of a product.
        - *Control Measures:* Mandatory "Double Recording" or Audio/Video recording where the RM must read a specific risk script and the client must verbally acknowledge understanding.

    ### 7. Typical Metrics and Measurement Methods
    - **Sales Conversion Rate:** (Number of successful subscription orders / Number of product pitches made) × 100%.
    - **Straight-Through Processing (STP) Rate:** Percentage of orders that pass from the RM input to the Fund House/Treasury without manual intervention or repair.
    - **Suitability Pass Rate:** Percentage of trades executed without requiring a "Risk Mismatch" waiver.
    - **Average Ticket Size:** Total subscription volume / Total number of transactions.
    - **Compliance Defect Ratio:** Number of transactions flagged for process errors (e.g., missing documents, unclear recording) / Total transactions reviewed.

    ### 8. Best Practices or Improvement Suggestions
    - **Suggestion 1: Digital Self-Service Integration:** Enable clients to complete Risk Profiling and simple Mutual Fund purchases via Mobile Banking app to reduce branch traffic and administrative load on RMs.
    - **Suggestion 2: Real-time Portfolio Simulation:** Integrate tools into the WMS that allow RMs to show clients "Before vs. After" scenarios of how a new investment affects their portfolio's risk/return characteristics during the sales pitch.
    - **Suggestion 3: Automated Fee Disclosure:** Automatically generate a simplified "Fee Impact Sheet" for every transaction that clearly calculates the exact dollar amount of fees (entry load + annual management fee) to improve transparency and trust.

    '''
    each_api_metadata = '''
        <TOOLS>

        <API>
        Name: ValidateExistingRiskProfile
        Description: Validates whether the client has an existing, unexpired risk profile assessment on file by comparing the previous_risk_profile_expiry_date against the current transaction_timestamp. Determines if a new risk assessment questionnaire administration is required or if the existing profile can be utilized for the investment transaction.
        Endpoint: /api/v1/risk-profile/validate
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "transaction_timestamp": "datetime (ISO 8601 format)",
        "previous_risk_profile": "enum (Conservative|Balanced|Aggressive) or null",
        "previous_risk_profile_expiry_date": "datetime (ISO 8601 format) or null"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "client_id": "string",
            "previous_risk_profile": "enum (Conservative|Balanced|Aggressive) or null",
            "previous_risk_profile_expiry_date": "datetime or null",
            "requires_new_assessment": "boolean",
            "validation_timestamp": "datetime",
            "profile_status": "string (valid|expired|not_found)"
        },
        "message": "string"
        }
        Dependencies: None (Entry point API)
        Error Scenarios:
        - Client ID not found in system: Return 404 with error message "Client not found", set requires_new_assessment = true
        - Invalid timestamp format: Return 400 with validation error message requesting ISO 8601 format
        - System clock unavailable: Return 500 with message "Unable to retrieve system timestamp", implement retry logic
        - Null previous_risk_profile with non-null expiry date (data inconsistency): Return 422 with message "Data inconsistency detected", set requires_new_assessment = true
        - Expiry date exactly equals transaction timestamp (boundary condition): Apply inclusive logic treating as expired, set requires_new_assessment = true
        </API>

        <API>
        Name: AdministerRiskQuestionnaire
        Description: Administers the regulatory-mandated Risk Tolerance Questionnaire to the client, collecting structured responses across multiple dimensions including age bracket, income stability, investment horizon, loss tolerance, and prior investment experience. Applies weighted scoring algorithm based on questionnaire responses to generate a numerical risk_questionnaire_total_score ranging from 0 to 100 points for subsequent risk profile classification.
        Endpoint: /api/v1/risk-profile/questionnaire
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "client_age": "integer",
        "client_annual_income": "float",
        "client_investment_experience_years": "integer",
        "client_liquidity_needs": "enum (Low|Medium|High)",
        "risk_questionnaire_responses": "JSON object containing structured questionnaire answers"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "client_id": "string",
            "risk_questionnaire_responses": "JSON object",
            "risk_questionnaire_total_score": "integer (0-100)",
            "score_breakdown": {
            "age_score": "integer",
            "income_stability_score": "integer",
            "investment_horizon_score": "integer",
            "loss_tolerance_score": "integer",
            "experience_score": "integer"
            },
            "assessment_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: ValidateExistingRiskProfile (state_dependency - only executes when requires_new_assessment = TRUE)
        Error Scenarios:
        - Invalid client_age (negative, zero, or > 120): Return 400 with message "Invalid client age value", request valid age between 1-120
        - Missing required questionnaire responses: Return 422 with message "Incomplete questionnaire responses", specify missing fields
        - Invalid client_investment_experience_years (negative): Return 400 with message "Investment experience years cannot be negative"
        - Scoring algorithm computation failure: Return 500 with message "Risk scoring calculation error", log for technical investigation
        - Client_age exactly at bracket boundary (e.g., 30, 40, 50, 60): Apply inclusive lower bound rule for bracket assignment
        - Inconsistent responses across related questions: Log warning, proceed with calculation using provided values
        - Risk score calculation results outside 0-100 range: Return 500 with message "Invalid risk score result", trigger algorithm review
        </API>

        <API>
        Name: CalculateRiskProfile
        Description: Applies deterministic mapping algorithm to convert numerical risk_questionnaire_total_score into categorical risk profile classification using regulatory-defined score ranges: Conservative (0-35 points), Balanced (36-65 points), and Aggressive (66-100 points). This classification serves as the foundation for all subsequent product suitability matching operations.
        Endpoint: /api/v1/risk-profile/calculate
        Method: POST
        Request Body:
        {
        "risk_questionnaire_total_score": "integer"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "risk_questionnaire_total_score": "integer",
            "calculated_risk_profile": "enum (Conservative|Balanced|Aggressive)",
            "profile_description": "string",
            "suitable_product_categories": "array of strings",
            "calculation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: AdministerRiskQuestionnaire (data_dependency - requires risk_questionnaire_total_score output)
        Error Scenarios:
        - Risk score outside valid range (< 0 or > 100): Return 400 with message "Risk score must be between 0 and 100", request valid score
        - Risk score exactly at classification boundary (35 or 65): Apply inclusive lower bound rule (35 = Conservative, 65 = Balanced)
        - Null or missing risk_questionnaire_total_score: Return 400 with message "Risk questionnaire score is required"
        - Invalid data type for risk score (non-integer): Return 400 with message "Risk score must be an integer value"
        - Classification mapping configuration unavailable: Return 500 with message "Risk profile classification service unavailable", implement retry with exponential backoff
        </API>

        <API>
        Name: AuthorizeAndActivateRiskProfile
        Description: Presents the calculated risk profile to the client for review and explicit consent, captures client authorization via configured method (OTP, Biometric, Physical_Signature, or Digital_Signature), computes risk profile expiry date by adding 730 days to current timestamp, and updates client master record to set investable_status to "Active" thereby enabling investment transaction processing.
        Endpoint: /api/v1/risk-profile/authorize
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "calculated_risk_profile": "enum (Conservative|Balanced|Aggressive)",
        "client_authorization_method": "enum (OTP|Biometric|Physical_Signature|Digital_Signature)",
        "transaction_timestamp": "datetime (ISO 8601 format)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "client_id": "string",
            "calculated_risk_profile": "enum (Conservative|Balanced|Aggressive)",
            "client_authorization_timestamp": "datetime",
            "risk_profile_expiry_date": "datetime",
            "investable_status": "enum (Active|Inactive)",
            "authorization_method_used": "string",
            "profile_validity_days": "integer"
        },
        "message": "string"
        }
        Dependencies: CalculateRiskProfile (data_dependency - requires calculated_risk_profile for client authorization)
        Error Scenarios:
        - Authorization method failure (OTP timeout after 300 seconds): Return 408 with message "Authorization timeout", allow retry up to 3 attempts
        - Biometric signature capture failure (match confidence < 95%): Return 401 with message "Biometric authentication failed", request re-scan
        - Client refuses to authorize calculated profile: Return 403 with message "Client authorization declined", terminate workflow and log refusal
        - Physical signature verification mismatch: Return 401 with message "Signature does not match specimen on file", request re-signature
        - CRM system update failure for investable_status: Return 500 with message "Unable to update client profile", implement compensating transaction rollback
        - Invalid client_authorization_method value: Return 400 with message "Invalid authorization method specified"
        - System unable to calculate expiry date (timestamp service failure): Return 500 with message "Unable to set profile expiry date", use default 730-day period
        - Client master record locked by concurrent process: Return 409 with message "Client record currently locked", implement retry with backoff
        </API>

        <API>
        Name: RecommendSuitableProducts
        Description: Queries product master database applying hierarchical suitability filters based on client calculated_risk_profile to return only investment products whose product_risk_rating aligns with or is lower than client risk tolerance according to regulatory suitability matrix. Conservative clients see Conservative and Moderate products; Balanced clients see Conservative, Moderate, and Balanced products; Aggressive clients see all product categories.
        Endpoint: /api/v1/products/recommend
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "calculated_risk_profile": "enum (Conservative|Balanced|Aggressive)",
        "investable_status": "enum (Active|Inactive)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "client_id": "string",
            "calculated_risk_profile": "string",
            "suitable_products_list": [
            {
                "product_code": "string",
                "product_name": "string",
                "product_risk_rating": "enum (Conservative|Moderate|Balanced|Growth|Aggressive)",
                "product_category": "enum (Mutual_Fund|Bond|Structured_Note|Dual_Currency_Investment|Principal_Protected_Note)",
                "current_nav": "float",
                "front_end_load_percentage": "float",
                "annual_management_fee_percentage": "float"
            }
            ],
            "total_suitable_products": "integer",
            "recommendation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: AuthorizeAndActivateRiskProfile (state_dependency - requires investable_status = "Active" before generating recommendations)
        Error Scenarios:
        - investable_status is not "Active": Return 403 with message "Client investable status is inactive", block product recommendations
        - No suitable products available for client risk profile: Return 200 with empty suitable_products_list array and message "No products currently match client risk profile"
        - Product master database unavailable: Return 503 with message "Product database temporarily unavailable", implement retry logic with circuit breaker
        - Invalid calculated_risk_profile value: Return 400 with message "Invalid risk profile specified"
        - Client_id not found: Return 404 with message "Client not found"
        - Product master data incomplete (missing risk ratings): Log warning, exclude products with incomplete data from recommendations
        - Concurrent product master update during query: Implement read consistency with snapshot isolation to prevent inconsistent results
        </API>

        <API>
        Name: CreateInvestmentOrder
        Description: Creates comprehensive new transaction record with system-generated transaction_id, captures all order parameters including client identification, relationship manager, product selection, subscription amount, and settlement account. Retrieves and populates product master data including risk rating, current NAV, fee structures. Assigns compliance officer based on transaction value and complexity. Records operational metadata including branch, channel, and region for reporting purposes.
        Endpoint: /api/v1/transactions/create
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "relationship_manager_id": "string",
        "product_code": "string",
        "subscription_amount": "float",
        "settlement_account_number": "string",
        "transaction_timestamp": "datetime (ISO 8601 format)",
        "branch_code": "string",
        "channel": "enum (Branch|Phone_Banking|Mobile_App|Online_Banking)",
        "region": "string"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "client_id": "string",
            "relationship_manager_id": "string",
            "transaction_type": "enum (Risk_Profiling|Mutual_Fund_Subscription|Structured_Product_Enrollment)",
            "product_code": "string",
            "product_name": "string",
            "product_risk_rating": "enum (Conservative|Moderate|Balanced|Growth|Aggressive)",
            "product_category": "enum (Mutual_Fund|Bond|Structured_Note|Dual_Currency_Investment|Principal_Protected_Note)",
            "subscription_amount": "float",
            "current_nav": "float",
            "front_end_load_percentage": "float",
            "annual_management_fee_percentage": "float",
            "settlement_account_number": "string",
            "compliance_officer_id": "string",
            "branch_code": "string",
            "channel": "string",
            "region": "string",
            "transaction_timestamp": "datetime",
            "order_creation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: RecommendSuitableProducts (state_dependency - logically follows product selection, requires client has investable_status = Active)
        Error Scenarios:
        - Product code not found in product master database: Return 404 with message "Product code does not exist", request valid product_code
        - Invalid settlement_account_number format: Return 400 with message "Invalid settlement account number format"
        - Settlement account not associated with client_id: Return 403 with message "Settlement account does not belong to client"
        - Subscription amount below product minimum investment threshold: Return 400 with message "Subscription amount below product minimum"
        - Subscription amount exceeds product maximum investment limit: Return 400 with message "Subscription amount exceeds product maximum"
        - Transaction ID generation conflict (duplicate): Retry generation with incremented sequence, implement idempotency with unique request key
        - Product master data incomplete (missing NAV or fees): Return 422 with message "Product data incomplete, cannot create order"
        - Relationship manager not authorized for product category: Return 403 with message "Relationship manager lacks certification for this product"
        - Compliance officer assignment algorithm failure: Return 500 with message "Unable to assign compliance officer", use default officer
        - Invalid channel specification: Return 400 with message "Invalid transaction channel"
        </API>

        <API>
        Name: ValidateProductSuitability
        Description: Executes automated real-time suitability check by comparing product_risk_rating against client calculated_risk_profile using hierarchical matching matrix enforcing regulatory suitability rules. Determines if product exceeds client risk tolerance, sets suitability_check_passed and suitability_mismatch_flag accordingly. Triggers mismatch waiver and supervisor approval workflow when violation detected, preventing transaction progression until proper override procedures completed.
        Endpoint: /api/v1/compliance/suitability-check
        Method: POST
        Request Body:
        {
        "transaction_id": "string",
        "calculated_risk_profile": "enum (Conservative|Balanced|Aggressive)",
        "product_risk_rating": "enum (Conservative|Moderate|Balanced|Growth|Aggressive)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "calculated_risk_profile": "string",
            "product_risk_rating": "string",
            "suitability_check_passed": "boolean",
            "suitability_mismatch_flag": "boolean",
            "mismatch_waiver_required": "boolean",
            "supervisor_approval_required": "boolean",
            "suitability_assessment": "string (suitable|unsuitable|marginally_suitable)",
            "mismatch_severity": "string (none|low|medium|high)",
            "validation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: 
        - CreateInvestmentOrder (data_dependency - requires transaction_id and product_risk_rating)
        - AuthorizeAndActivateRiskProfile or existing profile (data_dependency - requires calculated_risk_profile)
        Error Scenarios:
        - Suitability mismatch detected (product risk exceeds client tolerance): Return 200 with suitability_check_passed = FALSE, suitability_mismatch_flag = TRUE, trigger waiver workflow
        - Risk profile expired since transaction initiation: Return 409 with message "Risk profile expired during processing", require profile refresh
        - Invalid calculated_risk_profile value: Return 400 with message "Invalid client risk profile"
        - Invalid product_risk_rating value: Return 400 with message "Invalid product risk rating"
        - Transaction_id not found: Return 404 with message "Transaction not found"
        - Suitability matrix configuration missing: Return 500 with message "Suitability rules not configured", default to conservative blocking behavior
        - Product rating exactly matches client profile (boundary case): Apply permissive rule, set suitability_check_passed = TRUE
        - Multiple concurrent suitability checks for same transaction: Implement idempotency, return cached result if exists within 60 seconds
        </API>

        <API>
        Name: ExecuteAMLSanctionsScreening
        Description: Interfaces with enterprise AML monitoring platform to perform real-time sanctions list screening of client_id and client_name against all relevant sanctions databases including OFAC SDN list, EU consolidated sanctions, UN Security Council sanctions, and applicable national registries. Returns screening status indicating Clear (no matches), Flagged (potential match requiring manual review), or Pending (screening in progress).
        Endpoint: /api/v1/compliance/aml-screening
        Method: POST
        Request Body:
        {
        "client_id": "string",
        "client_name": "string",
        "transaction_id": "string"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "client_id": "string",
            "client_name": "string",
            "aml_sanctions_screening_status": "enum (Clear|Flagged|Pending)",
            "screening_reference_id": "string",
            "sanctions_lists_checked": "array of strings",
            "match_details": "array of objects (if Flagged)",
            "screening_timestamp": "datetime",
            "next_action_required": "string"
        },
        "message": "string"
        }
        Dependencies: CreateInvestmentOrder (data_dependency - requires transaction_id to associate screening with transaction, retrieves client_id)
        Error Scenarios:
        - AML platform timeout (> 10 seconds): Return 504 with message "AML screening timeout", implement exponential backoff retry up to 3 attempts
        - Sanctions match flagged requiring manual review: Return 200 with aml_sanctions_screening_status = "Flagged", block transaction progression, escalate to compliance officer
        - AML platform completely unavailable: Return 503 with message "AML service unavailable", route transaction to manual compliance review queue
        - Partial name match with low confidence score: Return 200 with status = "Flagged", provide match details for compliance officer disposition
        - Client name contains special characters causing screening error: Sanitize input, retry screening, if fails return 400 with message "Unable to process client name format"
        - Multiple sanctions hits across different lists: Return 200 with status = "Flagged", aggregate all match details in response
        - Screening result pending beyond acceptable timeframe (> 60 seconds): Return 202 with status = "Pending", implement polling mechanism
        - Client recently added to sanctions list (timing edge case): AML platform should catch, but if delayed return "Clear" initially, implement periodic re-screening
        </API>

        <API>
        Name: ValidateThresholdAndSOW
        Description: Compares subscription_amount against configured monitoring_threshold_amount (typically $100,000) to determine if transaction exceeds regulatory large-transaction threshold requiring enhanced due diligence. When threshold exceeded, validates that source_of_wealth_documented flag is TRUE indicating current and valid Source of Wealth documentation is on file. Blocks execution if SOW documentation missing for threshold-exceeding transactions.
        Endpoint: /api/v1/compliance/threshold-sow-check
        Method: POST
        Request Body:
        {
        "subscription_amount": "float",
        "monitoring_threshold_amount": "float",
        "source_of_wealth_documented": "boolean"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "subscription_amount": "float",
            "monitoring_threshold_amount": "float",
            "transaction_threshold_exceeded": "boolean",
            "source_of_wealth_documented": "boolean",
            "sow_validation_passed": "boolean",
            "threshold_percentage": "float",
            "validation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: CreateInvestmentOrder (data_dependency - requires subscription_amount from order creation)
        Error Scenarios:
        - Threshold exceeded but SOW not documented (source_of_wealth_documented = FALSE): Return 200 with sow_validation_passed = FALSE, block transaction with message "Source of Wealth documentation required"
        - SOW documentation expired (edge case requiring date validation): Return 428 with message "Source of Wealth documentation requires update"
        - Subscription amount exactly equals threshold (boundary condition): Apply inclusive rule, set transaction_threshold_exceeded = TRUE
        - Invalid subscription_amount (negative or zero): Return 400 with message "Invalid subscription amount"
        - Invalid monitoring_threshold_amount configuration: Return 500 with message "Threshold configuration error", use default $100,000
        - Multiple transactions aggregating to exceed threshold (requires client transaction history): Log warning for compliance review, validate current transaction independently
        - Currency conversion required for foreign currency subscriptions: Convert to USD equivalent before threshold comparison, document exchange rate used
        </API>

        <API>
        Name: VerifyFundsAvailability
        Description: Queries Core Banking System to retrieve real-time available_balance for specified settlement_account_number. Compares retrieved available_balance against subscription_amount to confirm sufficient liquid funds exist for transaction settlement without creating overdraft condition. Returns funds_availability_verified as TRUE only when available_balance >= subscription_amount.
        Endpoint: /api/v1/banking/verify-funds
        Method: POST
        Request Body:
        {
        "settlement_account_number": "string",
        "subscription_amount": "float"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "settlement_account_number": "string",
            "subscription_amount": "float",
            "available_balance": "float",
            "funds_availability_verified": "boolean",
            "balance_shortfall": "float",
            "balance_verification_timestamp": "datetime",
            "account_status": "string (active|frozen|restricted|closed)"
        },
        "message": "string"
        }
        Dependencies: CreateInvestmentOrder (data_dependency - requires settlement_account_number and subscription_amount)
        Error Scenarios:
        - Insufficient funds (available_balance < subscription_amount): Return 200 with funds_availability_verified = FALSE, calculate and return balance_shortfall
        - Settlement account frozen or restricted: Return 423 with message "Account locked, transaction cannot proceed", notify relationship manager
        - Settlement account closed: Return 410 with message "Account closed", require alternative settlement account
        - Core Banking System unavailable: Return 503 with message "Banking system temporarily unavailable", implement circuit breaker pattern with retry
        - Available balance exactly equals subscription amount (no buffer): Return 200 with funds_availability_verified = TRUE, log warning about zero remaining balance
        - Concurrent transactions depleting available balance: Implement pessimistic locking or optimistic concurrency control, return 409 if balance changed
        - Invalid settlement_account_number format: Return 400 with message "Invalid account number format"
        - Currency mismatch between account and subscription amount: Return 400 with message "Currency conversion required", provide FX rate
        - Account balance query timeout: Return 504 with message "Balance inquiry timeout", retry up to 2 times
        </API>

        <API>
        Name: AggregateComplianceChecks
        Description: Aggregates validation results from all parallel pre-trade compliance checks including suitability validation, AML sanctions screening, threshold/SOW validation, and funds availability verification. Applies boolean AND logic across all validation outcomes to produce consolidated pre_trade_compliance_passed flag. Transaction may proceed to execution only when ALL compliance checks return successful status.
        Endpoint: /api/v1/compliance/aggregate-checks
        Method: POST
        Request Body:
        {
        "suitability_check_passed": "boolean",
        "aml_sanctions_screening_status": "enum (Clear|Flagged|Pending)",
        "transaction_threshold_exceeded": "boolean",
        "source_of_wealth_documented": "boolean",
        "funds_availability_verified": "boolean"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "pre_trade_compliance_passed": "boolean",
            "suitability_check_passed": "boolean",
            "aml_check_passed": "boolean",
            "threshold_sow_check_passed": "boolean",
            "funds_check_passed": "boolean",
            "failed_checks": "array of strings",
            "compliance_summary": "string",
            "aggregation_timestamp": "datetime",
            "ready_for_execution": "boolean"
        },
        "message": "string"
        }
        Dependencies:
        - ValidateProductSuitability (data_dependency - requires suitability_check_passed)
        - ExecuteAMLSanctionsScreening (data_dependency - requires aml_sanctions_screening_status)
        - ValidateThresholdAndSOW (data_dependency - requires transaction_threshold_exceeded, implicitly uses source_of_wealth_documented)
        - VerifyFundsAvailability (data_dependency - requires funds_availability_verified)
        Error Scenarios:
        - One or more validations still pending: Return 202 with message "Compliance checks pending", implement polling mechanism with 60-second timeout
        - AML screening status = "Flagged": Set aml_check_passed = FALSE, pre_trade_compliance_passed = FALSE, block execution
        - AML screening status = "Pending": Return 202 with message "AML screening in progress", wait for completion
        - Threshold exceeded with undocumented SOW: Set threshold_sow_check_passed = FALSE, pre_trade_compliance_passed = FALSE
        - Conflicting validation results requiring manual review: Apply most restrictive rule, set pre_trade_compliance_passed = FALSE
        - Missing required validation input parameter: Return 400 with message "Incomplete compliance check inputs"
        - All checks passed but supervisor approval still required (from suitability mismatch): Return 200 with pre_trade_compliance_passed = TRUE but ready_for_execution = FALSE
        - Timeout waiting for all parallel checks to complete: Return 504 with message "Compliance aggregation timeout", route to manual review
        </API>

        <API>
        Name: CalculateTransactionFinancials
        Description: Computes comprehensive transaction financial metrics with regulatory precision: front_end_load_amount (subscription_amount × front_end_load_percentage / 100), net_investment_amount (subscription_amount - front_end_load_amount), estimated_units (net_investment_amount / current_nav for mutual funds with 4 decimal precision), and annual_management_fee_amount (net_investment_amount × annual_management_fee_percentage / 100). Provides transparent fee disclosure enabling client understanding of all costs and actual invested capital.
        Endpoint: /api/v1/transactions/calculate-financials
        Method: POST
        Request Body:
        {
        "subscription_amount": "float",
        "front_end_load_percentage": "float",
        "annual_management_fee_percentage": "float",
        "current_nav": "float",
        "product_category": "enum (Mutual_Fund|Bond|Structured_Note|Dual_Currency_Investment|Principal_Protected_Note)",
        "pre_trade_compliance_passed": "boolean"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "subscription_amount": "float",
            "front_end_load_percentage": "float",
            "front_end_load_amount": "float (2 decimal precision)",
            "net_investment_amount": "float (2 decimal precision)",
            "current_nav": "float",
            "estimated_units": "float (4 decimal precision)",
            "annual_management_fee_percentage": "float",
            "annual_management_fee_amount": "float (2 decimal precision)",
            "total_first_year_fees": "float",
            "effective_investment_percentage": "float",
            "calculation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies:
        - CreateInvestmentOrder (data_dependency - requires subscription_amount, front_end_load_percentage, annual_management_fee_percentage, current_nav, product_category)
        - AggregateComplianceChecks (state_dependency - only executes when pre_trade_compliance_passed = TRUE)
        Error Scenarios:
        - pre_trade_compliance_passed = FALSE: Return 403 with message "Transaction not compliant, cannot calculate financials"
        - Invalid current_nav (zero, negative, or null for Mutual_Fund): Return 400 with message "Invalid or missing NAV for mutual fund", request NAV refresh
        - Front-end load amount exceeds subscription amount (misconfiguration): Return 400 with message "Front-end load configuration error exceeds subscription"
        - Negative net_investment_amount after fee deduction: Return 400 with message "Fees exceed subscription amount, transaction cannot proceed"
        - Division by zero when calculating estimated_units (NAV = 0): Return 400 with message "Cannot calculate units with zero NAV"
        - Rounding precision loss causing material discrepancy: Apply banker's rounding (round half to even), log discrepancy if > 0.01%
        - Product_category is structured product but current_nav provided: Ignore NAV, set estimated_units = 0 (not applicable)
        - Invalid product_category value: Return 400 with message "Invalid product category"
        - Subscription amount is zero or negative: Return 400 with message "Invalid subscription amount for financial calculation"
        </API>

        <API>
        Name: ManageCoolingOffPeriod
        Description: Evaluates product_category against cooling-off period requirements to determine applicability (TRUE for Structured_Note, Dual_Currency_Investment, Principal_Protected_Note). When applicable, calculates cooling-off expiry timestamp by adding cooling_off_period_hours to client_authorization_timestamp. Sets transaction_status to "Pending_Cooling_Off" if cooling-off applies and period not elapsed, or "Ready_for_Execution" if cooling-off not required or period completed.
        Endpoint: /api/v1/transactions/manage-cooling-off
        Method: POST
        Request Body:
        {
        "transaction_id": "string",
        "product_category": "enum (Mutual_Fund|Bond|Structured_Note|Dual_Currency_Investment|Principal_Protected_Note)",
        "cooling_off_period_required": "boolean",
        "cooling_off_period_hours": "integer",
        "client_authorization_timestamp": "datetime (ISO 8601 format)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "product_category": "string",
            "cooling_off_period_required": "boolean",
            "cooling_off_period_hours": "integer",
            "client_authorization_timestamp": "datetime",
            "cooling_off_expiry_timestamp": "datetime or null",
            "transaction_status": "enum (Pending_Cooling_Off|Ready_for_Execution|Cancelled)",
            "hours_remaining": "integer or null",
            "status_determination_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: CalculateTransactionFinancials (state_dependency - executes after financial calculations complete, uses product_category)
        Error Scenarios:
        - Client requests cancellation during cooling-off period: Return 200 with transaction_status = "Cancelled", initiate refund workflow, log cancellation
        - Cooling-off expiry calculation error (timestamp arithmetic failure): Return 500 with message "Unable to calculate cooling-off expiry", use conservative longer period
        - Cooling-off period spans non-business days (weekends/holidays): Calculate based on actual hours, not business hours, document expiry datetime
        - Client authorization timestamp missing for cooling-off transaction: Return 400 with message "Authorization timestamp required for cooling-off calculation"
        - Transaction_id not found: Return 404 with message "Transaction not found"
        - Invalid cooling_off_period_hours (negative or > 168): Return 400 with message "Invalid cooling-off period configuration"
        - Current system time exactly equals cooling-off expiry (boundary condition): Apply inclusive rule, set status = "Ready_for_Execution"
        - Cooling-off period already expired at time of status check: Set transaction_status = "Ready_for_Execution", proceed to execution
        - System clock discrepancy affecting expiry calculation: Use UTC consistently, log warning if significant clock skew detected
        </API>

        <API>
        Name: ExecuteInvestmentTransaction
        Description: Final execution step consummating investment transaction through appropriate channel routing. For Mutual_Fund products, transmits electronic purchase order to fund house gateway with client and product details, receives trade_reference_number. For structured products, routes order to Treasury/Global Markets desk, receives contract_note_number. Instructs Core Banking System to debit settlement_account_number for full subscription_amount. Sets transaction_status to "Executed", records execution_timestamp, calculates settlement_date based on product-specific T+1 or T+2 cycles.
        Endpoint: /api/v1/transactions/execute
        Method: POST
        Request Body:
        {
        "transaction_id": "string",
        "product_category": "enum (Mutual_Fund|Bond|Structured_Note|Dual_Currency_Investment|Principal_Protected_Note)",
        "product_code": "string",
        "net_investment_amount": "float",
        "settlement_account_number": "string",
        "client_id": "string",
        "transaction_status": "enum (Ready_for_Execution|Pending_Cooling_Off)",
        "subscription_amount": "float"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "product_category": "string",
            "trade_reference_number": "string or null",
            "contract_note_number": "string or null",
            "execution_timestamp": "datetime",
            "settlement_date": "datetime",
            "transaction_status": "enum (Executed|Failed|Cancelled)",
            "settlement_account_debited": "boolean",
            "debit_reference_number": "string",
            "execution_channel": "string (fund_house|treasury_desk)",
            "settlement_cycle": "string (T+0|T+1|T+2)"
        },
        "message": "string"
        }
        Dependencies:
        - ManageCoolingOffPeriod (state_dependency - only executes when transaction_status = "Ready_for_Execution")
        - CalculateTransactionFinancials (data_dependency - requires net_investment_amount)
        - CreateInvestmentOrder (data_dependency - requires transaction_id, product_code, product_category, settlement_account_number, client_id)
        Error Scenarios:
        - Transaction status not "Ready_for_Execution": Return 409 with message "Transaction not ready for execution", specify current status
        - Fund house order gateway timeout or rejection: Return 502 with message "Fund house order rejected", set transaction_status = "Failed", log details
        - Core Banking System debit failure after order submitted: Return 500 with message "Settlement debit failed", initiate compensating transaction to reverse fund house order
        - Settlement account insufficient funds at execution time (race condition): Return 402 with message "Insufficient funds at execution", cancel order, set status = "Failed"
        - Settlement account frozen between validation and execution: Return 423 with message "Account locked, cannot execute", set status = "Failed"
        - Treasury desk manual review required for structured product: Return 202 with message "Order pending Treasury desk approval", maintain status in system
        - Duplicate execution attempt (idempotency violation): Return 200 with existing execution details if transaction already executed within 5 minutes
        - Invalid product_code at execution time: Return 404 with message "Product no longer available"
        - NAV changed significantly since order creation (> 5% for mutual funds): Log warning, proceed with execution at current NAV, document variance
        - Settlement date calculation falls on non-business day: Adjust to next business day using holiday calendar
        - Order routing system unavailable: Return 503 with message "Execution service unavailable", queue for retry with exponential backoff
        </API>

        <API>
        Name: CalculateSTPFlag
        Description: Evaluates entire transaction lifecycle to determine if straight-through processing was achieved by checking for any manual intervention indicators including suitability mismatch requiring waiver, supervisor approval requirements, AML screening flags, or back-office corrections. Sets straight_through_processing_flag to TRUE only for zero-touch transactions completing without human intervention, providing key operational efficiency metric for STP rate KPI reporting.
        Endpoint: /api/v1/transactions/calculate-stp
        Method: POST
        Request Body:
        {
        "transaction_id": "string",
        "suitability_mismatch_flag": "boolean",
        "supervisor_approval_required": "boolean",
        "aml_sanctions_screening_status": "enum (Clear|Flagged|Pending)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "straight_through_processing_flag": "boolean",
            "manual_intervention_indicators": "array of strings",
            "stp_assessment": "string (full_stp|partial_stp|manual_processing)",
            "automation_rate": "float (percentage)",
            "calculation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: ExecuteInvestmentTransaction (state_dependency - executes after transaction execution to evaluate complete lifecycle)
        Error Scenarios:
        - Transaction audit trail incomplete or missing: Return 200 with straight_through_processing_flag = FALSE (conservative approach), log data quality issue
        - Multiple contradictory STP indicators: Apply conservative rule, if any manual touchpoint detected set flag = FALSE
        - Transaction_id not found: Return 404 with message "Transaction not found"
        - Transaction not yet executed: Return 409 with message "Cannot calculate STP flag for incomplete transaction"
        - Suitability mismatch flag TRUE: Set straight_through_processing_flag = FALSE, add "suitability_override" to manual_intervention_indicators
        - Supervisor approval required TRUE: Set straight_through_processing_flag = FALSE, add "supervisor_approval" to manual_intervention_indicators
        - AML status "Flagged": Set straight_through_processing_flag = FALSE, add "aml_manual_review" to manual_intervention_indicators
        - Borderline scenario with minimal automated system correction: Apply strict interpretation, consider as STP if no human decision made
        </API>

        <API>
        Name: ExecutePostTradeComplianceReview
        Description: Performs post-execution quality assurance and regulatory compliance verification by reviewing transaction against standardized compliance checklist. Validates documentation completeness (disclosure_documents_presented), reviews audio_video_recording_id content quality for complex products, verifies suitability mismatch waiver documentation, and assesses overall transaction coherence relative to client profile. Documents findings in compliance_review_notes, sets compliance_defect_flag if violations or deficiencies identified requiring corrective action.
        Endpoint: /api/v1/compliance/post-trade-review
        Method: POST
        Request Body:
        {
        "transaction_id": "string",
        "audio_video_recording_id": "string or null",
        "suitability_mismatch_flag": "boolean",
        "transaction_threshold_exceeded": "boolean",
        "disclosure_documents_presented": "array of strings"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_id": "string",
            "compliance_defect_flag": "boolean",
            "compliance_review_notes": "string",
            "defects_identified": "array of strings",
            "documentation_complete": "boolean",
            "recording_quality_acceptable": "boolean or null",
            "review_completion_timestamp": "datetime",
            "reviewer_recommendation": "string (approve|escalate|remediate)",
            "follow_up_required": "boolean"
        },
        "message": "string"
        }
        Dependencies: ExecuteInvestmentTransaction (state_dependency - only executes after transaction status = "Executed")
        Error Scenarios:
        - Audio/video recording file corrupted or inaccessible: Set compliance_defect_flag = TRUE, add "recording_unavailable" to defects_identified, escalate for manual review
        - Mandatory disclosure documents missing from presented list: Set compliance_defect_flag = TRUE, document specific missing disclosures, require remediation
        - Suitability mismatch without proper waiver documentation: Set compliance_defect_flag = TRUE, critical violation requiring immediate escalation
        - Transaction threshold exceeded without evidence of SOW verification: Set compliance_defect_flag = TRUE, require retroactive SOW documentation
        - Transaction_id not found: Return 404 with message "Transaction not found"
        - Transaction not yet executed (premature review): Return 409 with message "Cannot review incomplete transaction"
        - Compliance officer unavailable for immediate review: Queue for next available officer, return 202 with message "Review queued"
        - Multiple defects identified requiring prioritization: Set compliance_defect_flag = TRUE, prioritize defects by severity in response
        - Recording quality insufficient for compliance verification: Set compliance_defect_flag = TRUE, require re-recording or enhanced documentation
        - Client profile inconsistencies identified during review: Set compliance_defect_flag = TRUE, recommend profile update and transaction re-evaluation
        </API>

        <API>
        Name: CalculateProcessingMetrics
        Description: Computes end-to-end transaction processing efficiency metrics by calculating total_processing_time_minutes as elapsed time between transaction_timestamp (initiation) and execution_timestamp (completion). Provides quantitative measure enabling monitoring of processing efficiency, cycle time analysis, identification of bottlenecks, and trend analysis for continuous process improvement initiatives.
        Endpoint: /api/v1/transactions/calculate-metrics
        Method: POST
        Request Body:
        {
        "transaction_timestamp": "datetime (ISO 8601 format)",
        "execution_timestamp": "datetime (ISO 8601 format)"
        }
        Response:
        {
        "status": "string (success|error)",
        "data": {
            "transaction_timestamp": "datetime",
            "execution_timestamp": "datetime",
            "total_processing_time_minutes": "integer",
            "processing_time_hours": "float",
            "processing_date_span": "integer (days)",
            "business_hours_processing_time": "integer (minutes)",
            "efficiency_rating": "string (excellent|good|acceptable|poor)",
            "calculation_timestamp": "datetime"
        },
        "message": "string"
        }
        Dependencies: ExecuteInvestmentTransaction (data_dependency - requires execution_timestamp for time calculation)
        Error Scenarios:
        - Execution timestamp missing or null: Return 400 with message "Execution timestamp required for metrics calculation"
        - Transaction timestamp missing or null: Return 400 with message "Transaction timestamp required for metrics calculation"
        - Execution timestamp precedes transaction timestamp (invalid data): Return 400 with message "Invalid timestamp sequence detected"
        - Negative time calculation due to clock skew: Return 500 with message "System time inconsistency detected", log for clock synchronization review
        - Processing time exceeds reasonable threshold (> 24 hours): Return 200 with calculated metrics, flag as anomaly for investigation
        - Transaction spans midnight causing date boundary complexity: Calculate elapsed time correctly accounting for date rollover
        - Timezone conversion issues for cross-region transactions: Ensure both timestamps in UTC before calculation
        - Very short processing time (< 1 minute for complex transaction): Return 200 with metrics, may indicate pre-validation or cached processing
        - Processing time calculation precision loss: Round to nearest integer minute, document rounding method
        </API>

        </TOOLS>'''
    
    sample_data = '''
        <data>
        ['transaction_id:INV_2025041801234', 'client_id:CLI_987654', 'client_name:John Michael Smith', 'client_age:45', 'client_annual_income:150000.00', 'client_net_worth:850000.00', 'client_investment_experience_years:8', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_4521', 'relationship_manager_name:Sarah Johnson', 'transaction_timestamp:2025-04-18T10:15:30Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_TECH_001', 'product_name:Global Tech Growth Fund', 'product_risk_rating:Growth', 'product_category:Mutual_Fund', 'subscription_amount:50000.00', 'front_end_load_percentage:2.5', 'annual_management_fee_percentage:1.75', 'current_nav:15.42', 'settlement_account_number:ACC_1234567890', 'available_balance:75000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Bonds_Alternatives"}', 'risk_questionnaire_total_score:78', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2025-03-15T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T10:45:22Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_7821', 'market_data_source:Bloomberg', 'branch_code:BR_NYC_001', 'channel:Branch', 'region:US_Northeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801235', 'client_id:CLI_123456', 'client_name:Maria Elena Rodriguez', 'client_age:32', 'client_annual_income:85000.00', 'client_net_worth:250000.00', 'client_investment_experience_years:3', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_3342', 'relationship_manager_name:Robert Chen', 'transaction_timestamp:2025-04-18T11:22:15Z', 'transaction_type:Risk_Profiling', 'product_code:', 'product_name:', 'product_risk_rating:', 'product_category:', 'subscription_amount:0.00', 'front_end_load_percentage:0.0', 'annual_management_fee_percentage:0.0', 'current_nav:0.0', 'settlement_account_number:ACC_9876543210', 'available_balance:35000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"31-40","q2_income_stability":"Stable","q3_investment_horizon":"3-5_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks"}', 'risk_questionnaire_total_score:52', 'previous_risk_profile:None', 'previous_risk_profile_expiry_date:', 'disclosure_documents_presented:[]', 'aml_sanctions_screening_status:Pending', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Biometric', 'client_authorization_timestamp:2025-04-18T11:35:48Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_6542', 'market_data_source:Internal_System', 'branch_code:BR_LA_005', 'channel:Branch', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801236', 'client_id:CLI_445566', 'client_name:David Thompson', 'client_age:67', 'client_annual_income:95000.00', 'client_net_worth:1200000.00', 'client_investment_experience_years:25', 'client_liquidity_needs:High', 'relationship_manager_id:RM_7788', 'relationship_manager_name:Jennifer Liu', 'transaction_timestamp:2025-04-18T09:05:12Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_BOND_055', 'product_name:Conservative Income Fund', 'product_risk_rating:Conservative', 'product_category:Mutual_Fund', 'subscription_amount:30000.00', 'front_end_load_percentage:1.5', 'annual_management_fee_percentage:0.95', 'current_nav:10.85', 'settlement_account_number:ACC_5544332211', 'available_balance:150000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"61+","q2_income_stability":"Retired_Fixed","q3_investment_horizon":"1-3_years","q4_loss_tolerance":"Very_Low","q5_previous_investments":"Bonds_CDs"}', 'risk_questionnaire_total_score:28', 'previous_risk_profile:Conservative', 'previous_risk_profile_expiry_date:2026-08-10T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Physical_Signature', 'client_authorization_timestamp:2025-04-18T09:28:45Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_8821', 'market_data_source:Reuters', 'branch_code:BR_MIA_012', 'channel:Branch', 'region:US_Southeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801237', 'client_id:CLI_778899', 'client_name:Priya Patel', 'client_age:38', 'client_annual_income:220000.00', 'client_net_worth:650000.00', 'client_investment_experience_years:12', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_2233', 'relationship_manager_name:Michael Torres', 'transaction_timestamp:2025-04-18T14:18:42Z', 'transaction_type:Structured_Product_Enrollment', 'product_code:SN_DCI_088', 'product_name:USD-EUR Dual Currency Investment', 'product_risk_rating:Aggressive', 'product_category:Dual_Currency_Investment', 'subscription_amount:120000.00', 'front_end_load_percentage:0.0', 'annual_management_fee_percentage:0.0', 'current_nav:0.0', 'settlement_account_number:ACC_7788990011', 'available_balance:185000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"31-40","q2_income_stability":"Stable","q3_investment_horizon":"10+_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Options_Forex"}', 'risk_questionnaire_total_score:82', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2026-11-22T00:00:00Z', 'disclosure_documents_presented:["Structured_Product_Term_Sheet","Risk_Disclosure_Statement","KID","Scenario_Analysis_Report"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:True', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:True', 'audio_video_recording_id:VR_2025041814001', 'cooling_off_period_required:True', 'cooling_off_period_hours:48', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T15:02:18Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_4455', 'market_data_source:Bloomberg', 'branch_code:BR_SF_008', 'channel:Branch', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801238', 'client_id:CLI_334455', 'client_name:Ahmed Hassan', 'client_age:29', 'client_annual_income:72000.00', 'client_net_worth:180000.00', 'client_investment_experience_years:2', 'client_liquidity_needs:High', 'relationship_manager_id:RM_9988', 'relationship_manager_name:Lisa Anderson', 'transaction_timestamp:2025-04-18T13:45:27Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_AGGR_122', 'product_name:Emerging Markets Equity Fund', 'product_risk_rating:Aggressive', 'product_category:Mutual_Fund', 'subscription_amount:15000.00', 'front_end_load_percentage:3.0', 'annual_management_fee_percentage:2.25', 'current_nav:22.18', 'settlement_account_number:ACC_4433221100', 'available_balance:18500.00', 'risk_questionnaire_responses:{"q1_age_bracket":"18-30","q2_income_stability":"Stable","q3_investment_horizon":"1-3_years","q4_loss_tolerance":"Low","q5_previous_investments":"Savings_Only"}', 'risk_questionnaire_total_score:25', 'previous_risk_profile:None', 'previous_risk_profile_expiry_date:', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T14:12:55Z', 'mismatch_waiver_required:True', 'mismatch_waiver_document_id:MW_2025041813001', 'supervisor_approval_required:True', 'supervisor_id:SUP_5566', 'compliance_officer_id:CO_3344', 'market_data_source:Reuters', 'branch_code:BR_CHI_015', 'channel:Branch', 'region:US_Midwest', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801239', 'client_id:CLI_556677', 'client_name:Elizabeth Wong', 'client_age:52', 'client_annual_income:195000.00', 'client_net_worth:1850000.00', 'client_investment_experience_years:18', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_6677', 'relationship_manager_name:Thomas Wright', 'transaction_timestamp:2025-04-18T08:30:15Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_BAL_045', 'product_name:Balanced Growth and Income Fund', 'product_risk_rating:Balanced', 'product_category:Mutual_Fund', 'subscription_amount:80000.00', 'front_end_load_percentage:2.0', 'annual_management_fee_percentage:1.45', 'current_nav:18.75', 'settlement_account_number:ACC_6655443322', 'available_balance:125000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"51-60","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds_Mutual_Funds"}', 'risk_questionnaire_total_score:58', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-02-28T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T09:05:42Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_7821', 'market_data_source:Bloomberg', 'branch_code:BR_BOS_020', 'channel:Online_Banking', 'region:US_Northeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801240', 'client_id:CLI_998877', 'client_name:Carlos Martinez', 'client_age:41', 'client_annual_income:135000.00', 'client_net_worth:420000.00', 'client_investment_experience_years:6', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_1122', 'relationship_manager_name:Angela Davis', 'transaction_timestamp:2025-04-18T16:22:33Z', 'transaction_type:Structured_Product_Enrollment', 'product_code:PPN_TECH_077', 'product_name:Tech Sector Principal Protected Note', 'product_risk_rating:Growth', 'product_category:Principal_Protected_Note', 'subscription_amount:75000.00', 'front_end_load_percentage:1.0', 'annual_management_fee_percentage:0.85', 'current_nav:0.0', 'settlement_account_number:ACC_9988776655', 'available_balance:92000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds"}', 'risk_questionnaire_total_score:62', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-07-15T00:00:00Z', 'disclosure_documents_presented:["Product_Term_Sheet","Risk_Disclosure_Statement","KID","Principal_Protection_Mechanism_Explanation"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:True', 'audio_video_recording_id:VR_2025041816002', 'cooling_off_period_required:True', 'cooling_off_period_hours:24', 'client_authorization_method:Biometric', 'client_authorization_timestamp:2025-04-18T16:58:17Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_5544', 'market_data_source:Bloomberg', 'branch_code:BR_HOU_018', 'channel:Branch', 'region:US_South', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801241', 'client_id:CLI_112233', 'client_name:Sandra Kowalski', 'client_age:58', 'client_annual_income:88000.00', 'client_net_worth:975000.00', 'client_investment_experience_years:22', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_4455', 'relationship_manager_name:Kevin Park', 'transaction_timestamp:2025-04-18T10:50:28Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_MOD_033', 'product_name:Moderate Allocation Fund', 'product_risk_rating:Moderate', 'product_category:Mutual_Fund', 'subscription_amount:45000.00', 'front_end_load_percentage:1.75', 'annual_management_fee_percentage:1.25', 'current_nav:12.34', 'settlement_account_number:ACC_1122334455', 'available_balance:62000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"51-60","q2_income_stability":"Stable","q3_investment_horizon":"3-5_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds_Mutual_Funds"}', 'risk_questionnaire_total_score:50', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-05-10T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T11:18:44Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_6655', 'market_data_source:Internal_System', 'branch_code:BR_SEA_022', 'channel:Phone_Banking', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801242', 'client_id:CLI_224466', 'client_name:Jason Lee', 'client_age:35', 'client_annual_income:112000.00', 'client_net_worth:310000.00', 'client_investment_experience_years:7', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_7799', 'relationship_manager_name:Patricia Moore', 'transaction_timestamp:2025-04-18T12:08:55Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_TECH_001', 'product_name:Global Tech Growth Fund', 'product_risk_rating:Growth', 'product_category:Mutual_Fund', 'subscription_amount:25000.00', 'front_end_load_percentage:2.5', 'annual_management_fee_percentage:1.75', 'current_nav:15.42', 'settlement_account_number:ACC_2244668800', 'available_balance:18000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"31-40","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_ETFs"}', 'risk_questionnaire_total_score:55', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-09-30T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T12:35:22Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_7788', 'market_data_source:Bloomberg', 'branch_code:BR_ATL_009', 'channel:Mobile_App', 'region:US_Southeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801243', 'client_id:CLI_667788', 'client_name:Fatima Al-Rashid', 'client_age:48', 'client_annual_income:275000.00', 'client_net_worth:2100000.00', 'client_investment_experience_years:15', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_8899', 'relationship_manager_name:David Kim', 'transaction_timestamp:2025-04-18T15:42:18Z', 'transaction_type:Structured_Product_Enrollment', 'product_code:SN_EQU_155', 'product_name:S&P 500 Linked Structured Note', 'product_risk_rating:Growth', 'product_category:Structured_Note', 'subscription_amount:150000.00', 'front_end_load_percentage:0.5', 'annual_management_fee_percentage:0.75', 'current_nav:0.0', 'settlement_account_number:ACC_6677889900', 'available_balance:280000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Bonds_Derivatives_Real_Estate"}', 'risk_questionnaire_total_score:75', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2027-01-15T00:00:00Z', 'disclosure_documents_presented:["Structured_Note_Term_Sheet","Risk_Disclosure_Statement","KID","Payoff_Scenario_Analysis","Credit_Risk_Disclosure"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:True', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:True', 'audio_video_recording_id:VR_2025041815003', 'cooling_off_period_required:True', 'cooling_off_period_hours:48', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T16:28:45Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_4455', 'market_data_source:Bloomberg', 'branch_code:BR_NYC_001', 'channel:Branch', 'region:US_Northeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801244', 'client_id:CLI_334567', 'client_name:Robert Jackson', 'client_age:71', 'client_annual_income:68000.00', 'client_net_worth:1450000.00', 'client_investment_experience_years:30', 'client_liquidity_needs:High', 'relationship_manager_id:RM_5566', 'relationship_manager_name:Michelle Green', 'transaction_timestamp:2025-04-18T09:25:40Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_BOND_022', 'product_name:Short-Term Bond Fund', 'product_risk_rating:Conservative', 'product_category:Mutual_Fund', 'subscription_amount:55000.00', 'front_end_load_percentage:0.75', 'annual_management_fee_percentage:0.65', 'current_nav:9.98', 'settlement_account_number:ACC_3345678901', 'available_balance:88000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"61+","q2_income_stability":"Retired_Fixed","q3_investment_horizon":"<1_year","q4_loss_tolerance":"Very_Low","q5_previous_investments":"Bonds_CDs_Money_Market"}', 'risk_questionnaire_total_score:32', 'previous_risk_profile:Conservative', 'previous_risk_profile_expiry_date:2026-12-05T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Physical_Signature', 'client_authorization_timestamp:2025-04-18T09:48:12Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_9900', 'market_data_source:Internal_System', 'branch_code:BR_PHX_025', 'channel:Branch', 'region:US_Southwest', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801245', 'client_id:CLI_445678', 'client_name:Nina Petrov', 'client_age:26', 'client_annual_income:58000.00', 'client_net_worth:85000.00', 'client_investment_experience_years:1', 'client_liquidity_needs:High', 'relationship_manager_id:RM_3344', 'relationship_manager_name:James Wilson', 'transaction_timestamp:2025-04-18T11:15:33Z', 'transaction_type:Risk_Profiling', 'product_code:', 'product_name:', 'product_risk_rating:', 'product_category:', 'subscription_amount:0.00', 'front_end_load_percentage:0.0', 'annual_management_fee_percentage:0.0', 'current_nav:0.0', 'settlement_account_number:ACC_4456789012', 'available_balance:12000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"18-30","q2_income_stability":"Stable","q3_investment_horizon":"3-5_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Savings_401k"}', 'risk_questionnaire_total_score:38', 'previous_risk_profile:None', 'previous_risk_profile_expiry_date:', 'disclosure_documents_presented:[]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T11:28:55Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_5566', 'market_data_source:Internal_System', 'branch_code:BR_DEN_011', 'channel:Online_Banking', 'region:US_Mountain', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801246', 'client_id:CLI_556789', 'client_name:William Chen', 'client_age:44', 'client_annual_income:165000.00', 'client_net_worth:720000.00', 'client_investment_experience_years:10', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_6688', 'relationship_manager_name:Emily Roberts', 'transaction_timestamp:2025-04-18T14:35:48Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_BAL_045', 'product_name:Balanced Growth and Income Fund', 'product_risk_rating:Balanced', 'product_category:Mutual_Fund', 'subscription_amount:95000.00', 'front_end_load_percentage:2.0', 'annual_management_fee_percentage:1.45', 'current_nav:18.75', 'settlement_account_number:ACC_5567890123', 'available_balance:105000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds_Mutual_Funds"}', 'risk_questionnaire_total_score:60', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-06-20T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Biometric', 'client_authorization_timestamp:2025-04-18T15:02:15Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_6677', 'market_data_source:Reuters', 'branch_code:BR_LA_005', 'channel:Branch', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801247', 'client_id:CLI_667890', 'client_name:Sophia Nguyen', 'client_age:39', 'client_annual_income:145000.00', 'client_net_worth:485000.00', 'client_investment_experience_years:9', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_7799', 'relationship_manager_name:Christopher Lee', 'transaction_timestamp:2025-04-18T10:42:20Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_GROW_099', 'product_name:International Growth Fund', 'product_risk_rating:Growth', 'product_category:Mutual_Fund', 'subscription_amount:40000.00', 'front_end_load_percentage:2.75', 'annual_management_fee_percentage:1.95', 'current_nav:24.56', 'settlement_account_number:ACC_6678901234', 'available_balance:55000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"31-40","q2_income_stability":"Stable","q3_investment_horizon":"10+_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Mutual_Funds_ETFs"}', 'risk_questionnaire_total_score:72', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2027-03-12T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T11:08:35Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_7788', 'market_data_source:Bloomberg', 'branch_code:BR_SF_008', 'channel:Online_Banking', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801248', 'client_id:CLI_778901', 'client_name:Daniel O\'Brien', 'client_age:55', 'client_annual_income:128000.00', 'client_net_worth:1125000.00', 'client_investment_experience_years:20', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_8811', 'relationship_manager_name:Rachel Martinez', 'transaction_timestamp:2025-04-18T13:18:25Z', 'transaction_type:Structured_Product_Enrollment', 'product_code:DCI_GBP_044', 'product_name:GBP-USD Dual Currency Investment', 'product_risk_rating:Aggressive', 'product_category:Dual_Currency_Investment', 'subscription_amount:110000.00', 'front_end_load_percentage:0.0', 'annual_management_fee_percentage:0.0', 'current_nav:0.0', 'settlement_account_number:ACC_7789012345', 'available_balance:145000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"51-60","q2_income_stability":"Stable","q3_investment_horizon":"3-5_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Bonds_Options_Forex"}', 'risk_questionnaire_total_score:68', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2026-10-18T00:00:00Z', 'disclosure_documents_presented:["Dual_Currency_Term_Sheet","Currency_Risk_Disclosure","KID","Scenario_Payoff_Matrix"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:True', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:True', 'audio_video_recording_id:VR_2025041813004', 'cooling_off_period_required:True', 'cooling_off_period_hours:48', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T14:05:52Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_4455', 'market_data_source:Bloomberg', 'branch_code:BR_CHI_015', 'channel:Branch', 'region:US_Midwest', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801249', 'client_id:CLI_889012', 'client_name:Grace Kim', 'client_age:63', 'client_annual_income:102000.00', 'client_net_worth:1680000.00', 'client_investment_experience_years:28', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_9922', 'relationship_manager_name:Brian Taylor', 'transaction_timestamp:2025-04-18T08:52:18Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_MOD_033', 'product_name:Moderate Allocation Fund', 'product_risk_rating:Moderate', 'product_category:Mutual_Fund', 'subscription_amount:65000.00', 'front_end_load_percentage:1.75', 'annual_management_fee_percentage:1.25', 'current_nav:12.34', 'settlement_account_number:ACC_8890123456', 'available_balance:98000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"61+","q2_income_stability":"Retired_Fixed","q3_investment_horizon":"3-5_years","q4_loss_tolerance":"Low","q5_previous_investments":"Bonds_Mutual_Funds_Annuities"}', 'risk_questionnaire_total_score:42', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-04-25T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Physical_Signature', 'client_authorization_timestamp:2025-04-18T09:22:45Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_8899', 'market_data_source:Internal_System', 'branch_code:BR_MIA_012', 'channel:Branch', 'region:US_Southeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801250', 'client_id:CLI_990123', 'client_name:Marcus Washington', 'client_age:47', 'client_annual_income:185000.00', 'client_net_worth:625000.00', 'client_investment_experience_years:11', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_1133', 'relationship_manager_name:Susan Chang', 'transaction_timestamp:2025-04-18T15:08:42Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_TECH_001', 'product_name:Global Tech Growth Fund', 'product_risk_rating:Growth', 'product_category:Mutual_Fund', 'subscription_amount:70000.00', 'front_end_load_percentage:2.5', 'annual_management_fee_percentage:1.75', 'current_nav:15.42', 'settlement_account_number:ACC_9901234567', 'available_balance:85000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"10+_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Bonds_Options_Real_Estate"}', 'risk_questionnaire_total_score:77', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2026-11-08T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T15:35:18Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_5544', 'market_data_source:Bloomberg', 'branch_code:BR_ATL_009', 'channel:Mobile_App', 'region:US_Southeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801251', 'client_id:CLI_101234', 'client_name:Linda Foster', 'client_age:50', 'client_annual_income:118000.00', 'client_net_worth:940000.00', 'client_investment_experience_years:16', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_2244', 'relationship_manager_name:Andrew Bennett', 'transaction_timestamp:2025-04-18T12:45:30Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_BAL_045', 'product_name:Balanced Growth and Income Fund', 'product_risk_rating:Balanced', 'product_category:Mutual_Fund', 'subscription_amount:85000.00', 'front_end_load_percentage:2.0', 'annual_management_fee_percentage:1.45', 'current_nav:18.75', 'settlement_account_number:ACC_1012345678', 'available_balance:92000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds_Mutual_Funds"}', 'risk_questionnaire_total_score:57', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-08-30T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Biometric', 'client_authorization_timestamp:2025-04-18T13:15:22Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_6677', 'market_data_source:Reuters', 'branch_code:BR_BOS_020', 'channel:Branch', 'region:US_Northeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801252', 'client_id:CLI_212345', 'client_name:Raj Sharma', 'client_age:36', 'client_annual_income:98000.00', 'client_net_worth:285000.00', 'client_investment_experience_years:5', 'client_liquidity_needs:Medium', 'relationship_manager_id:RM_3355', 'relationship_manager_name:Karen White', 'transaction_timestamp:2025-04-18T11:52:45Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_MOD_033', 'product_name:Moderate Allocation Fund', 'product_risk_rating:Moderate', 'product_category:Mutual_Fund', 'subscription_amount:35000.00', 'front_end_load_percentage:1.75', 'annual_management_fee_percentage:1.25', 'current_nav:12.34', 'settlement_account_number:ACC_2123456789', 'available_balance:42000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"31-40","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Mutual_Funds"}', 'risk_questionnaire_total_score:54', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-07-22T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:Digital_Signature', 'client_authorization_timestamp:2025-04-18T12:18:33Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_7788', 'market_data_source:Internal_System', 'branch_code:BR_SEA_022', 'channel:Phone_Banking', 'region:US_West', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801253', 'client_id:CLI_323456', 'client_name:Catherine Dubois', 'client_age:59', 'client_annual_income:142000.00', 'client_net_worth:1525000.00', 'client_investment_experience_years:24', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_4466', 'relationship_manager_name:Jonathan Reed', 'transaction_timestamp:2025-04-18T09:38:55Z', 'transaction_type:Structured_Product_Enrollment', 'product_code:PPN_DIV_099', 'product_name:Dividend Aristocrats Principal Protected Note', 'product_risk_rating:Balanced', 'product_category:Principal_Protected_Note', 'subscription_amount:125000.00', 'front_end_load_percentage:0.75', 'annual_management_fee_percentage:0.95', 'current_nav:0.0', 'settlement_account_number:ACC_3234567890', 'available_balance:165000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"51-60","q2_income_stability":"Stable","q3_investment_horizon":"5-10_years","q4_loss_tolerance":"Moderate","q5_previous_investments":"Stocks_Bonds_Real_Estate"}', 'risk_questionnaire_total_score:63', 'previous_risk_profile:Balanced', 'previous_risk_profile_expiry_date:2026-09-14T00:00:00Z', 'disclosure_documents_presented:["Product_Term_Sheet","Principal_Protection_Mechanism","Risk_Disclosure","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:True', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:True', 'audio_video_recording_id:VR_2025041809005', 'cooling_off_period_required:True', 'cooling_off_period_hours:24', 'client_authorization_method:Biometric', 'client_authorization_timestamp:2025-04-18T10:25:42Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_5544', 'market_data_source:Bloomberg', 'branch_code:BR_NYC_001', 'channel:Branch', 'region:US_Northeast', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        ['transaction_id:INV_2025041801254', 'client_id:CLI_434567', 'client_name:Thomas Mueller', 'client_age:42', 'client_annual_income:156000.00', 'client_net_worth:595000.00', 'client_investment_experience_years:13', 'client_liquidity_needs:Low', 'relationship_manager_id:RM_5577', 'relationship_manager_name:Nicole Brown', 'transaction_timestamp:2025-04-18T16:12:20Z', 'transaction_type:Mutual_Fund_Subscription', 'product_code:MF_GROW_099', 'product_name:International Growth Fund', 'product_risk_rating:Growth', 'product_category:Mutual_Fund', 'subscription_amount:60000.00', 'front_end_load_percentage:2.75', 'annual_management_fee_percentage:1.95', 'current_nav:24.56', 'settlement_account_number:ACC_4345678901', 'available_balance:78000.00', 'risk_questionnaire_responses:{"q1_age_bracket":"41-50","q2_income_stability":"Stable","q3_investment_horizon":"10+_years","q4_loss_tolerance":"High","q5_previous_investments":"Stocks_Mutual_Funds_ETFs_Options"}', 'risk_questionnaire_total_score:80', 'previous_risk_profile:Aggressive', 'previous_risk_profile_expiry_date:2027-02-05T00:00:00Z', 'disclosure_documents_presented:["Fund_Fact_Sheet","Prospectus","KID"]', 'aml_sanctions_screening_status:Clear', 'source_of_wealth_documented:True', 'transaction_threshold_exceeded:False', 'monitoring_threshold_amount:100000.00', 'audio_video_recording_required:False', 'audio_video_recording_id:', 'cooling_off_period_required:False', 'cooling_off_period_hours:0', 'client_authorization_method:OTP', 'client_authorization_timestamp:2025-04-18T16:42:38Z', 'mismatch_waiver_required:False', 'mismatch_waiver_document_id:', 'supervisor_approval_required:False', 'supervisor_id:', 'compliance_officer_id:CO_6655', 'market_data_source:Bloomberg', 'branch_code:BR_HOU_018', 'channel:Online_Banking', 'region:US_South', 'calculated_risk_profile:', 'risk_profile_expiry_date:', 'investable_status:', 'suitability_check_passed:', 'suitability_mismatch_flag:', 'pre_trade_compliance_passed:', 'funds_availability_verified:', 'estimated_units:', 'front_end_load_amount:', 'net_investment_amount:', 'annual_management_fee_amount:', 'trade_reference_number:', 'contract_note_number:', 'transaction_status:', 'execution_timestamp:', 'settlement_date:', 'straight_through_processing_flag:', 'compliance_defect_flag:', 'compliance_review_notes:', 'supervisor_approval_timestamp:', 'total_processing_time_minutes:'],
        </data>'''
    yaml_file = "/Invest/Deepseek-V3.2_graph_and_random_and_expand_affairs/prompts/SOP_API_Generation.yaml"
    system_prompt = "You are an SOP-related API tool JSON documentation generator. You must strictly follow the SOP logic to write all APIs, in the format already defined in each_api_metadata, sequentially into JSON format."
    # === 读取YAML并填充 ===
    user_prompt = load_yaml_prompt(yaml_file, sop_file_contents, additional_context, each_api_metadata, sample_data)

    # 初始化客户端
    client = OpenAI(
        api_key="",  # 请替换为你的 API Key
        base_url="https://"  # API 中转地址
    )

    # 创建流式对话
    response_chunks = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            }
        ],
        model="claude-sonnet-4-5-20250929",  # 指定模型
        max_tokens=49152,
        stream=True  # ➤ 开启流模式
    )

    full_response = ""  # 用于累积完整输出
    # 逐 chunk 读取流式输出
    for chunk in response_chunks:
        # 假设每个 chunk 的结构类似 OpenAI 官方： choices[0].delta.content
        # 你需要根据你客户端库的具体属性名做调整
        delta = chunk.choices[0].delta
        if hasattr(delta, "content") and delta.content:
            text = delta.content
            print(text, end="", flush=True)     # 实时打印输出
            full_response += text                # 累积内容

    # 当流结束后，full_response 即为完整的回复内容
    print("\n\n【流式输出结束】")

    # 将完整回复写入 txt 文件
    with open("api_json_response_output.txt", "w", encoding="utf-8") as file:
        file.write(full_response)

    print("完整回复已保存到 api_json_response_output.txt 文件")


if __name__ == "__main__":
    main()

import os
import yaml
from transformers import AutoTokenizer
from openai import OpenAI
def load_yaml_prompt(file_path, sop_title, additional_context):
    """读取YAML并替换占位符"""
    with open(file_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    text = data["prompts"]["text"]
    text = text.replace("{{sop_title}}", sop_title)
    text = text.replace("{{additional_context}}", additional_context)
    return text


def main():
    # === 输入参数 ===
    sop_title = "Banking Credit Card Issuance Scenario"
    additional_context = '''
    ### 1. Business Overview
    *   **Scenario Name:** Banking Credit Card Issuance & Origination
    *   **Industry:** Financial Services / Retail Banking
    *   **Primary Purpose / Value:** To systematically evaluate applicant creditworthiness, mitigate financial risk, and issue credit facilities (cards) to qualified customers. This process balances the bank's need for asset growth and customer acquisition with the strict requirement for regulatory compliance and risk management. The ultimate value is the creation of a profitable lending relationship and a frictionless onboarding experience for the customer.

    ### 2. Business Types (Sub-businesses)
    *   **Sub-business A: Retail Credit Card Application Processing:** Handling applications from individual consumers for personal use credit cards (e.g., Rewards, Cashback, Low Interest).
    *   **Sub-business B: Small Business/Corporate Card Issuance:** Processing applications from business entities for corporate expense management or working capital.
    *   **Sub-business C: Secured Credit Card Issuance:** Processing applications for customers with limited or poor credit history, requiring a cash collateral deposit.

    ### 3. Process Description
    *Note: These processes focus strictly on the issuance phase, ending with the final decision and credit limit assignment (deterministic outputs).*

    *   **Sub-business A: Retail Credit Card Application Processing**
        1)  **Step 1: Application Intake & Data Capture:** The system captures applicant PII (Personally Identifiable Information), employment data, income details, and housing status via digital channels (web/app) or branch entry.
        2)  **Step 2: Identity Verification (KYC/CIP):** The system automatically validates the applicant's identity against government databases and internal watchlists (OFAC, AML) to prevent fraud.
        3)  **Step 3: Credit Bureau Inquiry:** The system triggers a hard inquiry to major credit bureaus (Experian, TransUnion, Equifax) to retrieve the credit score, utilization ratios, and payment history.
        4)  **Step 4: Debt-to-Income (DTI) Calculation:** The engine calculates the applicant's ability to pay by comparing declared income against debt obligations found in the credit report.
        5)  **Step 5: Automated Decisioning & Scorecard Evaluation:** The application is run through the bank’s internal credit scorecard model. It generates a final risk score (e.g., 0-1000).
        6)  **Step 6: Final Output Generation:** The system outputs a binary decision (Approve/Decline) and, if approved, calculates the specific **Credit Limit (e.g., $5,000)** and **APR (e.g., 18.99%)**.

    *   **Sub-business B: Small Business/Corporate Card Issuance**
        1)  **Step 1: Entity & Guarantor Data Collection:** Collecting legal business documents (Articles of Incorporation, TIN/EIN) and personal details of the beneficial owner/guarantor.
        2)  **Step 2: Business Verification (KYB):** Validating the existence and active status of the business entity via Secretary of State registries and commercial credit bureaus (e.g., Dun & Bradstreet).
        3)  **Step 3: Blended Credit Assessment:** Pulling both the commercial credit report of the business and the personal credit report of the guarantor.
        4)  **Step 4: Cash Flow Analysis:** Analyzing business bank statements or tax returns (if uploaded) to determine average monthly revenue and volatility.
        5)  **Step 5: Underwriting Decision:** A credit underwriter (or automated system for small limits) reviews the blended risk profile.
        6)  **Step 6: Final Output Generation:** Deterministic output of **Approved Credit Line (e.g., $50,000)** and **Cardholder Limit Distribution** (how much limit per employee card).

    *   **Sub-business C: Secured Credit Card Issuance**
        1)  **Step 1: Application & Collateral Request:** Applicant submits personal details and agrees to provide a security deposit.
        2)  **Step 2: Deposit Verification:** The system verifies the receipt of the security deposit into a holding account (locking funds).
        3)  **Step 3: Risk Hygiene Check:** Basic checks for bankruptcy or active fraud alerts (credit score is less relevant here, but "derogatory marks" are checked).
        4)  **Step 4: Ratio Configuration:** The system applies the bank's LTV (Loan-to-Value) policy (usually 100% or 90% of the deposit).
        5)  **Step 5: Final Output Generation:** Outputs the **Approved Credit Limit** strictly equal to or representing a percentage of the **Verified Deposit Amount**.

    ### 4. Key Roles and Responsibilities
    *   **Applicant (Customer):** Provides accurate personal and financial data; consents to credit checks.
    *   **Credit Underwriter:** Reviews complex or borderline applications (manual review queues) that the automated system cannot decide; validates income documentation.
    *   **Fraud Analyst:** Investigates alerts generated by the identity verification system (e.g., address mismatches, synthetic identity suspicion).
    *   **Product Manager:** Defines the scorecard criteria, APR ranges, and credit limit strategies for specific card products.
    *   **Compliance Officer:** Ensures the application process adheres to regulations like ECOA (Equal Credit Opportunity Act) and FCRA (Fair Credit Reporting Act).

    ### 5. System and Tool Support
    *   **LOS (Loan Origination System):** The central platform that manages the workflow from application ingestion to final decisioning.
    *   **Decision Engine (BRE - Business Rule Engine):** Executes logic (e.g., "If Credit Score < 600, then Decline") and calculates the internal scorecard.
    *   **External Data Interface (API Gateway):** Connects to credit bureaus (Experian/Equifax) and fraud databases (LexisNexis/ChexSystems).
    *   **Document Management System (DMS):** Stores uploaded proofs of income (pay stubs) or identity (driver's license images) securely.

    ### 6. Risks and Control Points
    *   **Risk Point 1: Identity Fraud (Synthetic IDs):**
        *   *Control Measure:* Multi-factor authentication (OTP) during application; Knowledge-Based Authentication (KBA); device fingerprinting analysis.
    *   **Risk Point 2: Inaccurate Credit Decisioning (Bad Debt):**
        *   *Control Measure:* Regular back-testing of credit scorecards against actual default rates; automated DTI threshold enforcement.
    *   **Risk Point 3: Regulatory Non-Compliance (Fair Lending violations):**
        *   *Control Measure:* Automated auditing of decline reasons to ensure no decisions are based on protected class attributes (race, gender, etc.); generation of Adverse Action Letters.
    *   **Risk Point 4: Data Privacy Leakage:**
        *   *Control Measure:* Encryption of PII at rest and in transit; strict role-based access control (RBAC) within the LOS.

    ### 7. Typical Metrics and Measurement Methods
    *   **Approval Rate:** (Total Approved Applications / Total Applications Received) × 100. Indicates the quality of the applicant pool and the strictness of credit policy.
    *   **Turnaround Time (TAT):** Average time elapsed from "Application Submit" to "Final Decision Output." Measured in seconds for auto-decisions and hours/days for manual review.
    *   **Cost per Acquisition (CPA):** Total marketing and processing costs divided by the number of funded/activated accounts.
    *   **Auto-Decision Rate:** Percentage of applications processed without any human intervention. High rates indicate efficient automation.

    ### 8. Best Practices or Improvement Suggestions
    *   **Suggestion 1: Implement Open Banking API Integration:** Instead of asking customers to upload PDF bank statements or enter income manually, allow them to connect their primary bank account securely to instantly verify income and cash flow, reducing fraud and manual review time.
    *   **Suggestion 2: Dynamic Friction:** Apply "lighter" KYC checks for low-risk applicants (trusted devices/IPs) and step-up verification (document scan/biometrics) only for high-risk signals to improve conversion rates.
    *   **Suggestion 3: Pre-Qualification (Soft Pull):** Allow customers to see if they are likely to be approved without impacting their credit score (Soft Inquiry) before the formal submission (Hard Inquiry), improving the user experience and the quality of final applications.

    '''
    yaml_file = "/Credit_cards/Deepseek-V3.2_graph_and_random_and_expand_affairs/prompts/Schema_Generation.yaml"
    system_prompt = "You are an SOP dataset schema generator. Note that <Field_to_be_obtained></Field_to_be_obtained> should include several final output fields from the SOP, preferably numerical values, that can be used to determine if the process is correct."
    # 初始化客户端
    client = OpenAI(
        api_key="",  # 替换为你的API Key
        base_url="https://"  # API中转地址
    )
    # === 读取YAML并填充 ===
    user_prompt = load_yaml_prompt(yaml_file, sop_title, additional_context)

    # 创建对话
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            }
        ],
        model="claude-sonnet-4-5-20250929",  # 指定模型
    )

    print(chat_completion.choices[0].message.content)

if __name__ == "__main__":
    main()
